# ---------------------------------------------------------------------------
# Media3 / ExoPlayer
# Media3 is R8-friendly; only the reflectively instantiated renderer/extractor
# entry points need keeping. Keeping the whole library defeats shrinking.
# ---------------------------------------------------------------------------
-dontwarn androidx.media3.**
-keep class androidx.media3.exoplayer.DefaultRenderersFactory { *; }
-keepclassmembers class * extends androidx.media3.exoplayer.audio.AudioSink { *; }

# ---------------------------------------------------------------------------
# Room: only the generated implementations and entity field names matter.
# ---------------------------------------------------------------------------
-keep class * extends androidx.room.RoomDatabase
-keep class **_Impl { <init>(...); }
-keepclassmembers @androidx.room.Entity class * { <fields>; <init>(...); }
-dontwarn androidx.room.paging.**

# ---------------------------------------------------------------------------
# Domain models: used as Room projections, MediaItem extras and backup payload
# ---------------------------------------------------------------------------
-keepclassmembers class com.auralis.player.domain.model.** { <fields>; <init>(...); }

# ---------------------------------------------------------------------------
# Hilt / Dagger: the generated graph is referenced reflectively by name.
# ---------------------------------------------------------------------------
-keep,allowobfuscation @interface dagger.hilt.**
-keep class dagger.hilt.internal.aggregatedroot.codegen.** { *; }
-keep class hilt_aggregated_deps.** { *; }
-keep class **_HiltComponents* { *; }
-keep class * extends dagger.hilt.android.internal.lifecycle.HiltViewModelFactory { *; }
-dontwarn dagger.hilt.**

# ViewModels are instantiated reflectively by the ViewModel factory
-keepclassmembers class * extends androidx.lifecycle.ViewModel { <init>(...); }

# ---------------------------------------------------------------------------
# Kotlin metadata and enum values() used by name lookups (SmartField etc.)
# ---------------------------------------------------------------------------
-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

-dontwarn kotlinx.coroutines.**
-dontwarn androidx.compose.**

# ---------------------------------------------------------------------------
# Platform entry points declared in the manifest.
# ---------------------------------------------------------------------------
-keep class com.auralis.player.AuralisApp
-keep class com.auralis.player.MainActivity
-keep class com.auralis.player.playback.PlaybackService
-keep class com.auralis.player.playback.AuralisTileService
-keep class com.auralis.player.widget.CompactWidgetProvider
-keep class com.auralis.player.widget.MediumWidgetProvider
-keep class com.auralis.player.widget.LargeWidgetProvider
