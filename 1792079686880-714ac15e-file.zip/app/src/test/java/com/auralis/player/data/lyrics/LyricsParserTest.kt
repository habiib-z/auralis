package com.auralis.player.data.lyrics

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LyricsParserTest {

    @Test
    fun `timestamped lines are parsed and sorted`() {
        val lyrics = LyricsParser.parse(
            """
            [00:12.50]first line
            [00:05.00]earlier line
            """.trimIndent()
        )
        assertTrue(lyrics.synchronized)
        assertEquals(listOf(5_000L, 12_500L), lyrics.lines.map { it.timeMs })
        assertEquals("earlier line", lyrics.lines.first().text)
    }

    @Test
    fun `repeated timestamps on one line duplicate the text`() {
        val lyrics = LyricsParser.parse("[00:01.00][00:31.00]chorus")
        assertEquals(2, lyrics.lines.size)
        assertEquals(listOf("chorus", "chorus"), lyrics.lines.map { it.text })
        assertEquals(listOf(1_000L, 31_000L), lyrics.lines.map { it.timeMs })
    }

    @Test
    fun `fraction length decides the millisecond scale`() {
        assertEquals(1_500L, LyricsParser.parse("[00:01.5]x").lines.single().timeMs)
        assertEquals(1_050L, LyricsParser.parse("[00:01.05]x").lines.single().timeMs)
        assertEquals(1_005L, LyricsParser.parse("[00:01.005]x").lines.single().timeMs)
    }

    @Test
    fun `plain text falls back to unsynchronised lyrics`() {
        val lyrics = LyricsParser.parse("just\nsome\nwords")
        assertFalse(lyrics.synchronized)
        assertEquals(3, lyrics.lines.size)
    }
}
