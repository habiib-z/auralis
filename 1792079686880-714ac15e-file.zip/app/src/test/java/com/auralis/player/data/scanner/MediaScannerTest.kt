package com.auralis.player.data.scanner

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MediaScannerTest {

    @Test
    fun `exact folder is excluded`() {
        assertTrue(MediaScanner.isInside("/storage/emulated/0/Music", "/storage/emulated/0/Music"))
    }

    @Test
    fun `child folder is excluded`() {
        assertTrue(MediaScanner.isInside("/storage/emulated/0/Music/Rock", "/storage/emulated/0/Music"))
    }

    @Test
    fun `sibling with shared prefix is not excluded`() {
        assertFalse(MediaScanner.isInside("/storage/emulated/0/Music/Rockabilly", "/storage/emulated/0/Music/Rock"))
    }

    @Test
    fun `trailing slash on the excluded path is tolerated`() {
        assertTrue(MediaScanner.isInside("/Music/Rock/Live", "/Music/Rock/"))
        assertFalse(MediaScanner.isInside("/Music/Rockabilly", "/Music/Rock/"))
    }

    @Test
    fun `parent of the excluded folder stays included`() {
        assertFalse(MediaScanner.isInside("/storage/emulated/0", "/storage/emulated/0/Music"))
    }
}

class MoodClassifierTest {

    @Test
    fun `persian genre keywords are classified`() {
        assertEquals("Upbeat", MoodClassifier.classify("پاپ", 3 * 60_000, "آهنگ"))
        assertEquals("Romantic", MoodClassifier.classify("عاشقانه", 3 * 60_000, "آهنگ"))
    }

    @Test
    fun `duration decides when no keyword matches`() {
        assertEquals("Deep listen", MoodClassifier.classify("", 9 * 60_000, "untitled"))
        assertEquals("Quick hits", MoodClassifier.classify("", 60_000, "untitled"))
        assertEquals("Everyday", MoodClassifier.classify("", 4 * 60_000, "untitled"))
    }

    @Test
    fun `every classification is part of ALL`() {
        val produced = listOf(
            MoodClassifier.classify("metal", 200_000, ""),
            MoodClassifier.classify("pop", 200_000, ""),
            MoodClassifier.classify("عاشقانه", 200_000, ""),
            MoodClassifier.classify("", 9 * 60_000, ""),
            MoodClassifier.classify("", 60_000, ""),
            MoodClassifier.classify("", 200_000, "")
        )
        produced.forEach { assertTrue(it, it in MoodClassifier.ALL) }
    }
}
