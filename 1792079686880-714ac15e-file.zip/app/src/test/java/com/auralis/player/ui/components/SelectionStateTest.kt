package com.auralis.player.ui.components

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SelectionStateTest {

    @Test
    fun `starts inactive`() {
        val state = SelectionState()
        assertFalse(state.active)
        assertEquals(0, state.count)
    }

    @Test
    fun `toggle adds then removes`() {
        val state = SelectionState()
        state.toggle(7L)
        assertTrue(state.active)
        assertTrue(state.isSelected(7L))
        state.toggle(7L)
        assertFalse(state.active)
        assertFalse(state.isSelected(7L))
    }

    @Test
    fun `select all replaces the selection and clear ends it`() {
        val state = SelectionState()
        state.toggle(1L)
        state.selectAll(listOf(1L, 2L, 3L, 3L))
        assertEquals(3, state.count)
        state.clear()
        assertFalse(state.active)
    }
}
