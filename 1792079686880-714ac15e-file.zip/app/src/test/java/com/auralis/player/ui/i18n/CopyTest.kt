package com.auralis.player.ui.i18n

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CopyTest {

    @Test
    fun `english locale returns the key untouched`() {
        assertEquals("Appearance", Copy.translate(EnglishStrings, "Appearance"))
    }

    @Test
    fun `persian locale translates known copy`() {
        assertNotEquals("Appearance", Copy.translate(PersianStrings, "Appearance"))
    }

    @Test
    fun `unknown copy falls back to english instead of a placeholder`() {
        assertEquals("Not translated yet", Copy.translate(PersianStrings, "Not translated yet"))
    }

    @Test
    fun `persian strings table is marked rtl and english is not`() {
        assertTrue(PersianStrings.rtl)
        assertTrue(!EnglishStrings.rtl)
    }

    @Test
    fun `every strings field is localised`() {
        val fields = Strings::class.java.declaredFields.filter { it.type == String::class.java }
        fields.forEach { field ->
            field.isAccessible = true
            val en = field.get(EnglishStrings) as String
            val fa = field.get(PersianStrings) as String
            assertTrue("${field.name} is blank in PersianStrings", fa.isNotBlank())
            assertTrue("${field.name} is blank in EnglishStrings", en.isNotBlank())
        }
    }
}
