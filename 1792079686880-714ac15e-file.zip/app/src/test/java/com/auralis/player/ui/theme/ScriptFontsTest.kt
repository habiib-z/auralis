package com.auralis.player.ui.theme

import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.sp
import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * Guards the bug these cases describe: a Persian line that starts with a
 * quote, a bracket, a digit or a Latin word used to be laid out
 * left-to-right, which threw its first and last fragments to the wrong ends.
 */
class ScriptFontsTest {

    @Test
    fun `persian line keeps rtl even when it opens with punctuation`() {
        assertEquals(TextDirection.Rtl, ScriptFonts.baseDirection("\"دل من تنها شد\""))
        assertEquals(TextDirection.Rtl, ScriptFonts.baseDirection("(تکرار) شب از نیمه گذشت"))
        assertEquals(TextDirection.Rtl, ScriptFonts.baseDirection("1. آهسته برو ای ماه"))
    }

    @Test
    fun `persian line keeps rtl even when it opens with a latin word`() {
        assertEquals(TextDirection.Rtl, ScriptFonts.baseDirection("Oh ای یار من، کجا رفتی از این خانه"))
    }

    @Test
    fun `mostly latin line stays ltr`() {
        assertEquals(TextDirection.Ltr, ScriptFonts.baseDirection("Hold me closer tonight یار"))
    }

    @Test
    fun `line without letters inherits its context`() {
        assertEquals(TextDirection.Content, ScriptFonts.baseDirection("♪"))
        assertEquals(TextDirection.Content, ScriptFonts.baseDirection("1 2 3 ..."))
        assertEquals(TextDirection.Content, ScriptFonts.baseDirection(""))
    }

    @Test
    fun `tight line height is raised so persian lines cannot collide`() {
        val tight = TextStyle(fontSize = 22.sp, lineHeight = 22.sp)
        val fixed = ScriptFonts.withRtlMetrics(tight)
        assertEquals((22f * ScriptFonts.RTL_MIN_LINE_HEIGHT).sp, fixed.lineHeight)
        assertEquals(LineHeightStyle.Trim.None, fixed.lineHeightStyle?.trim)
    }

    @Test
    fun `a line height that is already generous is left alone`() {
        val roomy = TextStyle(fontSize = 22.sp, lineHeight = 40.sp)
        assertEquals(40.sp, ScriptFonts.withRtlMetrics(roomy).lineHeight)
    }
}
