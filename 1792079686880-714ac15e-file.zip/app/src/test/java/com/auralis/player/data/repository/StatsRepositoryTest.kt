package com.auralis.player.data.repository

import java.util.Calendar
import java.util.TimeZone
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class StatsRepositoryTest {

    private fun at(year: Int, month: Int, day: Int, hour: Int, minute: Int): Long =
        Calendar.getInstance().apply {
            clear()
            set(year, month, day, hour, minute, 0)
        }.timeInMillis

    @Test
    fun `day start is local midnight`() {
        val ms = at(2024, Calendar.MARCH, 15, 23, 45)
        val start = StatsRepository.localDayStart(ms)
        val cal = Calendar.getInstance().apply { timeInMillis = start }
        assertEquals(0, cal.get(Calendar.HOUR_OF_DAY))
        assertEquals(0, cal.get(Calendar.MINUTE))
        assertEquals(0, cal.get(Calendar.MILLISECOND))
        assertEquals(15, cal.get(Calendar.DAY_OF_MONTH))
    }

    @Test
    fun `moments within the same local day share a bucket`() {
        val morning = at(2024, Calendar.MARCH, 15, 0, 5)
        val night = at(2024, Calendar.MARCH, 15, 23, 55)
        assertEquals(StatsRepository.localDayStart(morning), StatsRepository.localDayStart(night))
    }

    @Test
    fun `consecutive days land in different buckets`() {
        val a = at(2024, Calendar.MARCH, 15, 23, 55)
        val b = at(2024, Calendar.MARCH, 16, 0, 5)
        assertNotEquals(StatsRepository.localDayStart(a), StatsRepository.localDayStart(b))
    }

    @Test
    fun `late evening east of UTC is not pushed into tomorrow`() {
        val previous = TimeZone.getDefault()
        try {
            TimeZone.setDefault(TimeZone.getTimeZone("Asia/Tehran"))
            val evening = at(2024, Calendar.MARCH, 15, 23, 0)
            val cal = Calendar.getInstance().apply { timeInMillis = StatsRepository.localDayStart(evening) }
            assertEquals(15, cal.get(Calendar.DAY_OF_MONTH))
        } finally {
            TimeZone.setDefault(previous)
        }
    }
}
