package com.auralis.player.data.lyrics

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LyricsLanguagesTest {

    @Test
    fun `file name suffix states the language`() {
        val fa = LyricsLanguages.fromSuffix("fa")
        assertEquals("fa", fa?.code)
        assertTrue(fa?.fromFileName == true)
        assertEquals("fa", LyricsLanguages.fromSuffix("farsi")?.code)
        assertEquals("fa", LyricsLanguages.fromSuffix("PER")?.code)
        assertEquals("en", LyricsLanguages.fromSuffix("eng")?.code)
    }

    @Test
    fun `unknown suffix is not invented`() {
        assertNull(LyricsLanguages.fromSuffix("v2"))
        assertNull(LyricsLanguages.fromSuffix("backup"))
    }

    @Test
    fun `translation suffix is reported as a role not a language`() {
        val t = LyricsLanguages.fromSuffix("translation")
        assertEquals("Translation", t?.label)
        assertEquals("", t?.code)
    }

    @Test
    fun `persian specific letters separate persian from arabic`() {
        val persian = LyricsLanguages.fromText("چشم‌های تو پنجره‌ای به گذشته است، ژاله روی برگ")
        assertEquals("fa", persian?.code)
        val arabic = LyricsLanguages.fromText("السلام عليكم ورحمة الله وبركاته، كلمات الأغنية هنا")
        assertEquals("ar", arabic?.code)
    }

    @Test
    fun `scripts shared by many languages are reported as scripts`() {
        assertEquals("Latin script", LyricsLanguages.fromText("Hello darkness my old friend")?.label)
        assertEquals("Cyrillic script", LyricsLanguages.fromText("Привет это текст песни здесь")?.label)
    }

    @Test
    fun `too little text yields no claim`() {
        assertNull(LyricsLanguages.fromText("ok"))
        assertNull(LyricsLanguages.fromText("[00:12.00]"))
    }
}
