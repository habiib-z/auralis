package com.auralis.player.ui.theme

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.TextUnitType
import androidx.compose.ui.unit.sp

/**
 * Script-aware font selection.
 *
 * The bundled Vazir face is used only for text that actually contains Persian
 * / Arabic characters; Latin text keeps the platform family untouched, so an
 * English title never picks up the Persian face. Detection is per string, so a
 * mixed library renders each row with the correct family.
 */
object ScriptFonts {

    @Volatile
    private var persian: FontFamily? = null

    /** Resolves (and caches) the Persian font family from `res/font`. */
    fun persianFamily(context: Context): FontFamily {
        persian?.let { return it }
        val family = AuralisFonts.resolve(context.applicationContext)
        persian = family
        return family
    }

    private fun isRtlLetter(c: Char): Boolean =
        c in '\u0590'..'\u05FF' ||   // Hebrew
            c in '\u0600'..'\u06FF' || // Arabic / Persian
            c in '\u0700'..'\u074F' || // Syriac
            c in '\u0750'..'\u077F' ||
            c in '\u08A0'..'\u08FF' ||
            c in '\uFB1D'..'\uFDFF' ||
            c in '\uFE70'..'\uFEFF'

    private fun isLtrLetter(c: Char): Boolean =
        c.isLetter() && !isRtlLetter(c)

    /**
     * Base paragraph direction for a single line, decided by which script
     * actually dominates it.
     *
     * [TextDirection.Content] looks only at the *first* strong character, so a
     * Persian line that opens with a quote, a bracket, a digit or a Latin word
     * is laid out left-to-right. The visible symptom is punctuation and short
     * Latin fragments jumping between the start and the end of the line. A
     * majority vote over the whole line gives the result a reader expects.
     *
     * Returns [TextDirection.Content] when the line carries no letters at all,
     * so empty or purely numeric lines keep inheriting their context.
     */
    fun baseDirection(text: String): TextDirection {
        var rtl = 0
        var ltr = 0
        for (c in text) {
            when {
                isRtlLetter(c) -> rtl++
                isLtrLetter(c) -> ltr++
            }
            if (rtl + ltr > 400) break
        }
        return when {
            rtl == 0 && ltr == 0 -> TextDirection.Content
            rtl >= ltr -> TextDirection.Rtl
            else -> TextDirection.Ltr
        }
    }

    /**
     * Smallest line box a Persian / Arabic line can use, as a multiple of the
     * font size.
     *
     * Vazir, like most Arabic-script faces, draws well above and below the
     * Latin x-height band: dots sit under be/pe/je, and the loops of je, che
     * and ye reach further down than any Latin descender. At a 1.0 multiple
     * the line box is shorter than the glyphs, so the tail of one line lands
     * on top of the next and the words read as if they had spilled over.
     */
    const val RTL_MIN_LINE_HEIGHT = 1.45f

    /**
     * Gives [style] a line box tall enough for Arabic-script glyphs and stops
     * the line-height trimming that clips the first and last line.
     */
    fun withRtlMetrics(style: TextStyle): TextStyle {
        val size = style.fontSize
        val floor = if (size != TextUnit.Unspecified && size.type == TextUnitType.Sp) {
            size.value * RTL_MIN_LINE_HEIGHT
        } else {
            0f
        }
        val current = style.lineHeight
        val resolved = when {
            floor <= 0f -> current
            current == TextUnit.Unspecified || current.type != TextUnitType.Sp -> floor.sp
            current.value < floor -> floor.sp
            else -> current
        }
        return style.copy(
            lineHeight = resolved,
            lineHeightStyle = LineHeightStyle(
                alignment = LineHeightStyle.Alignment.Center,
                trim = LineHeightStyle.Trim.None
            )
        )
    }

    /** True when the string holds at least one Persian / Arabic character. */
    fun containsRtl(text: String): Boolean {
        for (c in text) {
            if (c in '\u0600'..'\u06FF' || c in '\u0750'..'\u077F' ||
                c in '\u08A0'..'\u08FF' || c in '\uFB50'..'\uFDFF' ||
                c in '\uFE70'..'\uFEFF'
            ) {
                return true
            }
        }
        return false
    }
}

/** Remembers the resolved Persian (Vazir) font family. */
@Composable
fun rememberPersianFontFamily(): FontFamily {
    val context = LocalContext.current
    return remember { ScriptFonts.persianFamily(context) }
}

/**
 * Returns [base] tuned for [text]: the Persian family when the text is
 * Persian / Arabic and [enabled] is set, and always a base writing direction
 * taken from the dominant script of the string.
 *
 * The direction part is not optional, because it is what keeps the start and
 * the end of a line in place. Use for song titles, artist names, lyrics and
 * the alphabetical index.
 */
@Composable
fun localizedStyle(base: TextStyle, text: String, enabled: Boolean = true): TextStyle {
    val persian = rememberPersianFontFamily()
    return remember(base, text, persian, enabled) {
        val rtl = ScriptFonts.containsRtl(text)
        val direction = ScriptFonts.baseDirection(text)
        var style = base
        if (rtl && enabled) style = style.copy(fontFamily = persian)
        if (direction != base.textDirection) style = style.copy(textDirection = direction)
        // Metrics follow the script, not the font setting: the glyphs need the
        // room whether or not the bundled face is in use.
        if (rtl) style = ScriptFonts.withRtlMetrics(style)
        style
    }
}
