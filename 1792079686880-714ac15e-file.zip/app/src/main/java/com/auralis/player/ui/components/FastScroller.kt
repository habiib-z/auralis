package com.auralis.player.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.auralis.player.ui.theme.AuralisTheme
import com.auralis.player.ui.theme.AuralisType
import com.auralis.player.ui.theme.localizedStyle
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * Fast scroller overlay for large song lists: drag the thumb to jump to any
 * index, with a floating bubble showing the label at the target.
 *
 * The overlay only claims a touch that lands on the thumb itself (plus a small
 * slack), so the row controls underneath it — the overflow button in
 * particular — keep receiving their taps.
 */
@Composable
fun FastScroller(
    listState: LazyListState,
    itemCount: Int,
    modifier: Modifier = Modifier,
    getLabel: ((Int) -> String)? = null,
    thumbHeight: Dp = 56.dp,
    hitBoxWidth: Dp = 28.dp
) {
    if (itemCount <= 1) return

    val density = LocalDensity.current
    val coroutineScope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val colors = AuralisTheme.colors
    val motion = AuralisTheme.motion

    var isDragging by remember { mutableStateOf(false) }
    var dragY by remember { mutableFloatStateOf(0f) }
    var currentLabel by remember { mutableStateOf("") }
    var lastHapticLabel by remember { mutableStateOf("") }
    var lastTargetIndex by remember { mutableIntStateOf(-1) }
    var scrollJob by remember { mutableStateOf<Job?>(null) }

    // Auto-dimming: active during scroll or drag, subtly visible when idle
    var isActive by remember { mutableStateOf(false) }
    LaunchedEffect(listState.isScrollInProgress, isDragging) {
        if (listState.isScrollInProgress || isDragging) {
            isActive = true
        } else {
            delay(1800)
            isActive = false
        }
    }

    val alpha by animateFloatAsState(
        targetValue = if (isActive || isDragging) 1f else 0f,
        animationSpec = tween(durationMillis = 260),
        label = "fastScrollerAlpha"
    )

    val thumbWidth by animateDpAsState(
        targetValue = if (isDragging) 8.dp else 5.dp,
        animationSpec = motion.popSpring(),
        label = "fastScrollerThumbWidth"
    )

    BoxWithConstraints(modifier = modifier) {
        val trackHeightPx = constraints.maxHeight.toFloat()
        val thumbHeightPx = with(density) { thumbHeight.toPx() }
        val maxOffset = (trackHeightPx - thumbHeightPx).coerceAtLeast(1f)

        // Compute normal thumb offset from list scroll progress
        val listFraction by remember(itemCount) {
            derivedStateOf {
                val firstIndex = listState.firstVisibleItemIndex
                if (itemCount > 1) {
                    (firstIndex.toFloat() / (itemCount - 1)).coerceIn(0f, 1f)
                } else 0f
            }
        }

        val normalThumbY = listFraction * maxOffset
        val currentThumbY = if (isDragging) dragY else normalThumbY
        // Mirrored into state so the gesture handler hit-tests the thumb where
        // it is right now instead of where it was when the handler was built.
        val thumbTop = remember { mutableFloatStateOf(0f) }
        thumbTop.floatValue = currentThumbY

        // Floating letter bubble shown during drag
        AnimatedVisibility(
            visible = isDragging && currentLabel.isNotEmpty(),
            enter = fadeIn(motion.tweenFast()) + scaleIn(motion.popSpring()),
            exit = fadeOut(motion.tweenFast()) + scaleOut(motion.tweenFast()),
            modifier = Modifier
                .align(Alignment.TopEnd)
                .offset {
                    val bubbleSizePx = 52.dp.roundToPx()
                    val xOffset = -56.dp.roundToPx()
                    val yOffset = (currentThumbY + thumbHeightPx / 2f - bubbleSizePx / 2f)
                        .roundToInt()
                        .coerceIn(0, (trackHeightPx - bubbleSizePx).roundToInt().coerceAtLeast(0))
                    IntOffset(x = xOffset, y = yOffset)
                }
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .shadow(8.dp, CircleShape)
                    .clip(CircleShape)
                    .background(colors.accent),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = currentLabel,
                    style = localizedStyle(AuralisType.headline, currentLabel),
                    color = colors.onAccent,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Hit box and track
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .fillMaxHeight()
                .width(hitBoxWidth)
                .alpha(alpha)
                .pointerInput(itemCount, maxOffset) {
                    val slackPx = with(density) { 20.dp.toPx() }
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        // Only a touch on the thumb belongs to the scroller.
                        // Anything else falls through to the row underneath,
                        // so the overflow button stays tappable.
                        val top = thumbTop.floatValue - slackPx
                        val bottom = thumbTop.floatValue + thumbHeightPx + slackPx
                        if (!isActive || down.position.y < top || down.position.y > bottom) {
                            return@awaitEachGesture
                        }
                        down.consume()
                        isDragging = true

                        fun updatePosition(pointerY: Float) {
                            val clamped = (pointerY - thumbHeightPx / 2f).coerceIn(0f, maxOffset)
                            dragY = clamped
                            val fraction = (clamped / maxOffset).coerceIn(0f, 1f)
                            val targetIndex = (fraction * (itemCount - 1)).roundToInt().coerceIn(0, itemCount - 1)

                            val label = getLabel?.invoke(targetIndex) ?: ""
                            currentLabel = label
                            if (label.isNotEmpty() && label != lastHapticLabel) {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                lastHapticLabel = label
                            }

                            if (targetIndex != lastTargetIndex) {
                                lastTargetIndex = targetIndex
                                scrollJob?.cancel()
                                scrollJob = coroutineScope.launch {
                                    listState.scrollToItem(targetIndex)
                                }
                            }
                        }

                        updatePosition(down.position.y)

                        while (true) {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull { it.id == down.id } ?: break
                            if (!change.pressed) break
                            change.consume()
                            updatePosition(change.position.y)
                        }
                        isDragging = false
                    }
                }
        ) {
            // Subtle vertical track rail
            Box(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 7.dp)
                    .width(2.dp)
                    .fillMaxHeight()
                    .clip(CircleShape)
                    .background(colors.outline.copy(alpha = 0.2f))
            )

            // Draggable thumb pill
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(end = (7.dp - thumbWidth / 2))
                    .offset { IntOffset(x = 0, y = currentThumbY.roundToInt()) }
                    .width(thumbWidth)
                    .height(thumbHeight)
                    .clip(CircleShape)
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                colors.accent,
                                colors.accentGlow
                            )
                        )
                    )
            )
        }
    }
}
