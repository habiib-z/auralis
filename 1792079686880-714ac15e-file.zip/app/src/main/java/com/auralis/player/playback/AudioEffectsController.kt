package com.auralis.player.playback

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.PresetReverb
import android.media.audiofx.Virtualizer
import android.util.Log
import com.auralis.player.domain.model.EqualizerPreset
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

data class EqualizerState(
    val available: Boolean = false,
    val enabled: Boolean = false,
    val bandCount: Int = 5,
    val centerFrequencies: List<Int> = emptyList(),
    val minLevelMb: Int = -1500,
    val maxLevelMb: Int = 1500,
    val levelsMb: List<Int> = emptyList(),
    val presetName: String = "Flat",
    val bassBoostSupported: Boolean = false,
    val virtualizerSupported: Boolean = false,
    val loudnessSupported: Boolean = false,
    val bassBoost: Int = 0,
    val trebleBoost: Int = 0,
    val virtualizer: Int = 0,
    val loudness: Int = 0
)

/**
 * Wraps the platform audio effects. Every control degrades gracefully when the
 * device does not expose a given effect, so no UI control is ever fake.
 */
@Singleton
class AudioEffectsController @Inject constructor() {

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var loudness: LoudnessEnhancer? = null
    private var presetReverb: PresetReverb? = null
    private var sessionId: Int = 0

    /** The user's equalizer curve, before the treble offset is added. */
    private var baseLevels: List<Int> = emptyList()
    private var trebleStrength: Int = 0

    private val _state = MutableStateFlow(EqualizerState())
    val state: StateFlow<EqualizerState> = _state.asStateFlow()

    @Synchronized
    fun attach(audioSessionId: Int) {
        if (audioSessionId == 0 || audioSessionId == sessionId) return
        release()
        sessionId = audioSessionId
        runCatching {
            equalizer = Equalizer(0, audioSessionId)
        }.onFailure { Log.w(TAG, "Equalizer unavailable", it) }
        runCatching { bassBoost = BassBoost(0, audioSessionId) }
        runCatching { virtualizer = Virtualizer(0, audioSessionId) }
        runCatching { loudness = LoudnessEnhancer(audioSessionId) }
        runCatching { presetReverb = PresetReverb(0, audioSessionId) }
        publish()
    }

    @Synchronized
    fun release() {
        runCatching { equalizer?.release() }
        runCatching { bassBoost?.release() }
        runCatching { virtualizer?.release() }
        runCatching { loudness?.release() }
        runCatching { presetReverb?.release() }
        equalizer = null
        bassBoost = null
        virtualizer = null
        loudness = null
        presetReverb = null
        sessionId = 0
    }

    fun setEnabled(enabled: Boolean) {
        runCatching { equalizer?.enabled = enabled }
        runCatching { bassBoost?.enabled = enabled && _state.value.bassBoost > 0 }
        runCatching { virtualizer?.enabled = enabled && _state.value.virtualizer > 0 }
        runCatching { loudness?.enabled = enabled && _state.value.loudness > 0 }
        _state.value = _state.value.copy(enabled = enabled)
    }

    fun setBandLevel(band: Int, levelMb: Int) {
        val eq = equalizer ?: return
        val levels = _state.value.levelsMb.toMutableList()
        while (levels.size <= band) levels.add(0)
        levels[band] = levelMb
        baseLevels = levels.toList()
        applyCurve()
        _state.value = _state.value.copy(levelsMb = levels, enabled = true, presetName = "Custom")
        runCatching { eq.enabled = true }
    }

    fun applyLevels(levelsMb: List<Int>, presetName: String) {
        equalizer ?: return
        baseLevels = levelsMb
        applyCurve()
        _state.value = _state.value.copy(levelsMb = levelsMb, presetName = presetName, enabled = true)
    }

    fun setBassBoost(strength: Int) {
        val clamped = strength.coerceIn(0, 1000)
        runCatching {
            bassBoost?.let {
                it.enabled = clamped > 0
                it.setStrength(clamped.toShort())
            }
        }
        _state.value = _state.value.copy(bassBoost = clamped)
    }

    /**
     * Treble is implemented by lifting the top equalizer bands. The lift is an
     * *offset on top of* the user's curve, not a replacement: the previous
     * version overwrote the top two bands outright, silently destroying the
     * selected preset (and fighting applyLevels).
     */
    fun setTrebleBoost(strength: Int) {
        val clamped = strength.coerceIn(0, 1000)
        trebleStrength = clamped
        applyCurve()
        _state.value = _state.value.copy(trebleBoost = clamped)
    }

    /**
     * Writes `baseLevels` plus the treble offset to the device equalizer.
     * `baseLevels` is the user's curve as chosen by a preset or a band slider,
     * so the offset can be changed back and forth without losing it.
     */
    private fun applyCurve() {
        val eq = equalizer ?: return
        runCatching {
            val bands = eq.numberOfBands.toInt()
            if (bands <= 0) return@runCatching
            val min = eq.bandLevelRange[0].toInt()
            val max = eq.bandLevelRange[1].toInt()
            val lift = (max * trebleStrength / 1000.0).toInt()
            eq.enabled = true
            for (band in 0 until bands) {
                val base = baseLevels.getOrElse(band) { 0 }
                val boosted = if (band >= bands - 2) base + lift else base
                eq.setBandLevel(band.toShort(), boosted.coerceIn(min, max).toShort())
            }
        }
    }

    fun setVirtualizer(strength: Int) {
        val clamped = strength.coerceIn(0, 1000)
        runCatching {
            virtualizer?.let {
                it.enabled = clamped > 0
                it.setStrength(clamped.toShort())
            }
        }
        _state.value = _state.value.copy(virtualizer = clamped)
    }

    fun setLoudness(gainMb: Int) {
        val clamped = gainMb.coerceIn(0, 2000)
        runCatching {
            loudness?.let {
                it.setTargetGain(clamped)
                it.enabled = clamped > 0
            }
        }
        _state.value = _state.value.copy(loudness = clamped)
    }

    fun setTargetLoudness(targetDb: Int) {
        val gainMb = ((targetDb - NEUTRAL_LOUDNESS_DB) * 100).coerceAtLeast(0)
        setLoudness(gainMb)
    }

    fun setReverbPreset(preset: Int) {
        val rev = presetReverb ?: return
        runCatching {
            if (preset <= 0) {
                rev.enabled = false
            } else {
                rev.preset = preset.toShort()
                rev.enabled = true
            }
        }
    }

    fun currentLevels(): List<Int> = _state.value.levelsMb

    private fun publish() {
        val eq = equalizer
        if (eq == null) {
            _state.value = EqualizerState(available = false)
            return
        }
        val bands = runCatching { eq.numberOfBands.toInt() }.getOrDefault(0)
        val range = runCatching { eq.bandLevelRange }.getOrNull()
        _state.value = EqualizerState(
            available = bands > 0,
            enabled = runCatching { eq.enabled }.getOrDefault(false),
            bandCount = bands,
            centerFrequencies = (0 until bands).map {
                runCatching { eq.getCenterFreq(it.toShort()) / 1000 }.getOrDefault(0)
            },
            minLevelMb = range?.get(0)?.toInt() ?: -1500,
            maxLevelMb = range?.get(1)?.toInt() ?: 1500,
            levelsMb = (0 until bands).map {
                runCatching { eq.getBandLevel(it.toShort()).toInt() }.getOrDefault(0)
            },
            bassBoostSupported = runCatching { bassBoost?.strengthSupported == true }.getOrDefault(false),
            virtualizerSupported = runCatching { virtualizer?.strengthSupported == true }.getOrDefault(false),
            loudnessSupported = loudness != null
        )
    }

    companion object {
        private const val TAG = "AudioEffects"
        const val NEUTRAL_LOUDNESS_DB = -14

        /** Built-in presets expressed as relative gain per band (-10..10). */
        val BUILT_IN_PRESETS: List<Pair<String, List<Int>>> = listOf(
            "Flat" to listOf(0, 0, 0, 0, 0),
            "Rock" to listOf(5, 3, -1, 3, 5),
            "Pop" to listOf(-1, 3, 5, 2, -1),
            "Classical" to listOf(4, 2, -2, 3, 5),
            "Jazz" to listOf(3, 2, -1, 2, 4),
            "Electronic" to listOf(6, 2, 0, 2, 6),
            "Hip-Hop" to listOf(7, 4, -1, 2, 4),
            "Vocal" to listOf(-3, 1, 6, 3, -2),
            "Bass Boost" to listOf(9, 6, 1, 0, 0),
            "Acoustic" to listOf(4, 2, 1, 3, 4)
        )

        fun presetToMillibels(preset: List<Int>, bandCount: Int, minMb: Int, maxMb: Int): List<Int> {
            if (bandCount <= 0) return emptyList()
            return (0 until bandCount).map { index ->
                val position = if (bandCount == 1) 0f else index.toFloat() / (bandCount - 1)
                val sourceIndex = position * (preset.size - 1)
                val low = preset[sourceIndex.toInt().coerceIn(0, preset.lastIndex)]
                val high = preset[(sourceIndex.toInt() + 1).coerceIn(0, preset.lastIndex)]
                val fraction = sourceIndex - sourceIndex.toInt()
                val value = low + (high - low) * fraction
                (value / 10f * maxMb).toInt().coerceIn(minMb, maxMb)
            }
        }

        fun asPresetList(): List<EqualizerPreset> = BUILT_IN_PRESETS.mapIndexed { index, (name, levels) ->
            EqualizerPreset(-(index + 1).toLong(), name, levels, isBuiltIn = true)
        }
    }
}
