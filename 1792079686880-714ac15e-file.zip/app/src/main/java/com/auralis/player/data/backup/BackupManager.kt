package com.auralis.player.data.backup

import android.content.Context
import android.net.Uri
import com.auralis.player.data.prefs.SettingsRepository
import com.auralis.player.data.repository.MusicRepository
import com.auralis.player.data.repository.PlaylistRepository
import com.auralis.player.domain.model.AccentPalette
import com.auralis.player.domain.model.AppTheme
import com.auralis.player.domain.model.ThemeMode
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec
import javax.inject.Inject
import javax.inject.Singleton

data class RestoreSummary(
    val favorites: Int,
    val pinned: Int,
    val playlists: Int,
    val settingsApplied: Boolean
)

/**
 * Backup of everything personal: favorites, pinned songs, playlists and the
 * visual/theme settings.
 *
 * Two formats are written and read:
 *  - `AURB1`: AES-256/GCM with a key compiled into the app. This is
 *    obfuscation, **not** security — the key ships with every APK, so anyone
 *    with the file and the app can read it. It exists for backwards
 *    compatibility with files exported by earlier versions.
 *  - `AURB2`: AES-256/GCM with a key derived from a user passphrase via
 *    PBKDF2-HMAC-SHA256 (210k iterations, random 16-byte salt). This is real
 *    encryption and is used whenever the user supplies a passphrase.
 *
 * Songs are referenced by absolute file path (MediaStore ids differ between
 * devices), so restores match tracks wherever the files live again.
 */
@Singleton
class BackupManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val musicRepository: MusicRepository,
    private val playlistRepository: PlaylistRepository,
    private val settingsRepository: SettingsRepository
) {

    // ------------------------------------------------------------------
    // Crypto
    // ------------------------------------------------------------------

    private val magicV1 = "AURB1".toByteArray(Charsets.US_ASCII)
    private val magicV2 = "AURB2".toByteArray(Charsets.US_ASCII)

    /** Legacy, app-embedded key. Obfuscation only — kept to read old files. */
    private fun legacyKey(): SecretKeySpec {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest("auralis.backup.v1::com.auralis.player::x7Q9mK2pL5vT8sW1".toByteArray())
        return SecretKeySpec(digest, "AES")
    }

    private fun derivedKey(passphrase: CharArray, salt: ByteArray): SecretKeySpec {
        val spec = PBEKeySpec(passphrase, salt, PBKDF2_ITERATIONS, 256)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        return SecretKeySpec(factory.generateSecret(spec).encoded, "AES")
    }

    private fun encrypt(plain: ByteArray, passphrase: String?): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        return if (passphrase.isNullOrEmpty()) {
            cipher.init(Cipher.ENCRYPT_MODE, legacyKey())
            val iv = cipher.iv
            magicV1 + byteArrayOf(iv.size.toByte()) + iv + cipher.doFinal(plain)
        } else {
            val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
            cipher.init(Cipher.ENCRYPT_MODE, derivedKey(passphrase.toCharArray(), salt))
            val iv = cipher.iv
            magicV2 + byteArrayOf(salt.size.toByte()) + salt +
                byteArrayOf(iv.size.toByte()) + iv + cipher.doFinal(plain)
        }
    }

    private fun decrypt(data: ByteArray, passphrase: String?): ByteArray {
        val isV2 = data.size > magicV2.size &&
            data.copyOfRange(0, magicV2.size).contentEquals(magicV2)
        val isV1 = data.size > magicV1.size &&
            data.copyOfRange(0, magicV1.size).contentEquals(magicV1)
        require(isV1 || isV2) { "This file is not an Auralis backup" }

        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        return if (isV2) {
            require(!passphrase.isNullOrEmpty()) { "This backup needs its passphrase" }
            var cursor = magicV2.size
            val saltLen = data[cursor].toInt(); cursor += 1
            val salt = data.copyOfRange(cursor, cursor + saltLen); cursor += saltLen
            val ivLen = data[cursor].toInt(); cursor += 1
            val iv = data.copyOfRange(cursor, cursor + ivLen); cursor += ivLen
            cipher.init(
                Cipher.DECRYPT_MODE,
                derivedKey(passphrase.toCharArray(), salt),
                GCMParameterSpec(128, iv)
            )
            cipher.doFinal(data, cursor, data.size - cursor)
        } else {
            val ivLen = data[magicV1.size].toInt()
            val ivStart = magicV1.size + 1
            val iv = data.copyOfRange(ivStart, ivStart + ivLen)
            cipher.init(Cipher.DECRYPT_MODE, legacyKey(), GCMParameterSpec(128, iv))
            cipher.doFinal(data, ivStart + ivLen, data.size - ivStart - ivLen)
        }
    }

    // ------------------------------------------------------------------
    // Payload
    // ------------------------------------------------------------------

    private suspend fun buildPayload(): JSONObject {
        // Cold start: give the library a moment to load before snapshotting.
        withTimeoutOrNull(15_000) { musicRepository.songs.first { it.isNotEmpty() } }

        val settings = settingsRepository.settings.first()
        val songs = musicRepository.songs.value
        val songById = songs.associateBy { it.id }

        val favorites = JSONArray()
        songs.filter { it.isFavorite }.forEach { favorites.put(it.path) }

        val pinned = JSONArray()
        settings.pinnedSongs.mapNotNull { songById[it]?.path }.forEach { pinned.put(it) }

        val playlists = JSONArray()
        playlistRepository.playlists.value.forEach { playlist ->
            val members = playlistRepository.songsOf(playlist.id).first()
            val arr = JSONArray()
            members.forEach { arr.put(it.path) }
            playlists.put(
                JSONObject()
                    .put("name", playlist.name)
                    .put("songs", arr)
            )
        }

        val theme = JSONObject()
            .put("appTheme", settings.appTheme.name)
            .put("themeMode", settings.themeMode.name)
            .put("accent", settings.accent.name)
            .put("customAccent", settings.customAccent)
            .put("startScreen", settings.startScreen)
            .put("gridStyle", settings.gridStyle.name)

        return JSONObject()
            .put("format", "auralis-backup")
            .put("version", 1)
            .put("exportedAt", System.currentTimeMillis())
            .put("theme", theme)
            .put("favorites", favorites)
            .put("pinned", pinned)
            .put("playlists", playlists)
    }

    private suspend fun applyPayload(json: JSONObject): RestoreSummary {
        require(json.optString("format") == "auralis-backup") { "This file is not an Auralis backup" }

        // Wait for the library so path matching has something to match against.
        withTimeoutOrNull(15_000) { musicRepository.songs.first { it.isNotEmpty() } }
        val byPath = musicRepository.songs.value.associateBy { it.path }

        // --- theme / settings ---
        var settingsApplied = false
        json.optJSONObject("theme")?.let { theme ->
            runCatching { AppTheme.valueOf(theme.optString("appTheme")) }
                .getOrNull()?.let { settingsRepository.setAppTheme(it) }
            runCatching { ThemeMode.valueOf(theme.optString("themeMode")) }
                .getOrNull()?.let { settingsRepository.setThemeMode(it) }
            runCatching { AccentPalette.valueOf(theme.optString("accent")) }
                .getOrNull()?.let { settingsRepository.setAccent(it) }
            if (theme.has("customAccent")) settingsRepository.setCustomAccent(theme.optLong("customAccent"))
            theme.optString("startScreen").takeIf { it.isNotBlank() }
                ?.let { settingsRepository.setStartScreen(it) }
            runCatching { com.auralis.player.domain.model.GridStyle.valueOf(theme.optString("gridStyle")) }
                .getOrNull()?.let { settingsRepository.setGridStyle(it) }
            settingsApplied = true
        }

        // --- favorites ---
        var favoriteCount = 0
        json.optJSONArray("favorites")?.let { favorites ->
            for (i in 0 until favorites.length()) {
                byPath[favorites.optString(i)]?.let { song ->
                    musicRepository.setFavorite(song.id, true)
                    favoriteCount++
                }
            }
        }

        // --- pinned ---
        var pinnedCount = 0
        json.optJSONArray("pinned")?.let { pinned ->
            val ids = mutableSetOf<Long>()
            for (i in 0 until pinned.length()) {
                byPath[pinned.optString(i)]?.let { ids += it.id }
            }
            if (ids.isNotEmpty()) {
                settingsRepository.setPinnedSongs(ids)
                pinnedCount = ids.size
            }
        }

        // --- playlists (skip name collisions to avoid duplicates) ---
        var playlistCount = 0
        json.optJSONArray("playlists")?.let { playlists ->
            val existing = playlistRepository.playlists.value.map { it.name }.toSet()
            for (i in 0 until playlists.length()) {
                val entry = playlists.optJSONObject(i) ?: continue
                val name = entry.optString("name")
                if (name.isBlank() || name in existing) continue
                val songIds = mutableListOf<Long>()
                entry.optJSONArray("songs")?.let { arr ->
                    for (j in 0 until arr.length()) {
                        byPath[arr.optString(j)]?.let { songIds += it.id }
                    }
                }
                playlistRepository.create(name, songIds)
                playlistCount++
            }
        }

        return RestoreSummary(favoriteCount, pinnedCount, playlistCount, settingsApplied)
    }

    // ------------------------------------------------------------------
    // Public API
    // ------------------------------------------------------------------

    suspend fun exportTo(uri: Uri, passphrase: String? = null) = withContext(Dispatchers.IO) {
        val bytes = encrypt(buildPayload().toString().toByteArray(Charsets.UTF_8), passphrase)
        context.contentResolver.openOutputStream(uri, "wt")?.use { it.write(bytes) }
            ?: error("Could not open the selected location")
    }

    suspend fun importFrom(uri: Uri, passphrase: String? = null): RestoreSummary =
        withContext(Dispatchers.IO) {
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: error("Could not read the selected file")
        val json = JSONObject(String(decrypt(bytes, passphrase), Charsets.UTF_8))
        applyPayload(json)
    }

    /** Runs at app start; writes a dated backup at most once per day. */
    suspend fun autoBackupIfDue() {
        val settings = settingsRepository.settings.first()
        if (!settings.autoBackupEnabled) return
        val dayMs = 20L * 60 * 60 * 1000 // ~daily, tolerant of open times
        if (System.currentTimeMillis() - settings.lastAutoBackupAt < dayMs) return

        withContext(Dispatchers.IO) {
            val dir = File(context.getExternalFilesDir(null) ?: context.filesDir, "backups")
            dir.mkdirs()
            val stamp = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())
            val file = File(dir, "Auralis-auto-$stamp.aur")
            file.writeBytes(encrypt(buildPayload().toString().toByteArray(Charsets.UTF_8), null))
            // keep the 7 most recent auto backups
            dir.listFiles { f -> f.name.startsWith("Auralis-auto-") }
                ?.sortedByDescending { it.lastModified() }
                ?.drop(7)
                ?.forEach { it.delete() }
        }
        settingsRepository.setLastAutoBackup(System.currentTimeMillis())
    }

    fun suggestedFileName(): String {
        val stamp = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())
        return "Auralis-backup-$stamp.aur"
    }

    companion object {
        /** OWASP 2023 guidance for PBKDF2-HMAC-SHA256. */
        private const val PBKDF2_ITERATIONS = 210_000
    }
}
