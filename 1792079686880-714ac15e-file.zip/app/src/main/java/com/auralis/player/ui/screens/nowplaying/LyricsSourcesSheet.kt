package com.auralis.player.ui.screens.nowplaying

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Inventory2
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.auralis.player.data.lyrics.LyricsCandidate
import com.auralis.player.data.lyrics.LyricsOrigin
import com.auralis.player.presentation.LyricsSourcesState
import com.auralis.player.ui.components.AuralisChip
import com.auralis.player.ui.components.SheetHandle
import com.auralis.player.ui.components.combinedClickableCompat
import com.auralis.player.ui.i18n.t
import com.auralis.player.ui.theme.AuralisTheme
import com.auralis.player.ui.theme.AuralisType
import com.auralis.player.ui.theme.localizedStyle

/**
 * Lyrics source chooser.
 *
 * A track can have a saved copy, one or more `.lrc` files beside it (often in
 * different languages), a tag inside the file and several online matches. The
 * app used to silently take the first hit; here every version is listed with
 * its origin, language, whether it is time-synced and how many lines it has,
 * and the user decides. Any version can also be applied as the translation,
 * which is how a second language gets paired with the original.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LyricsSourcesSheet(
    state: LyricsSourcesState,
    persianFont: Boolean,
    onChoose: (LyricsCandidate, Boolean) -> Unit,
    onRetry: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = AuralisTheme.colors
    val spacing = AuralisTheme.spacing
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var asTranslation by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = colors.backgroundElevated,
        dragHandle = { SheetHandle() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = spacing.screen)
                .padding(bottom = spacing.md),
            verticalArrangement = Arrangement.spacedBy(spacing.sm)
        ) {
            Text(
                text = t("Choose lyrics"),
                style = AuralisType.headline,
                color = colors.textPrimary
            )
            Text(
                text = t("Versions found for this track. Pick the one you want to see."),
                style = AuralisType.bodySmall,
                color = colors.textSecondary
            )

            Row(horizontalArrangement = Arrangement.spacedBy(spacing.xs)) {
                AuralisChip(label = t("As lyrics"), selected = !asTranslation) { asTranslation = false }
                AuralisChip(
                    label = t("As translation"),
                    selected = asTranslation,
                    leadingIcon = Icons.Rounded.Translate
                ) { asTranslation = true }
            }

            when (state) {
                LyricsSourcesState.Hidden -> Unit

                LyricsSourcesState.Searching -> Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = spacing.xl),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(color = colors.accent, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    Text(
                        text = t("Looking for versions…"),
                        style = AuralisType.bodySmall,
                        color = colors.textSecondary,
                        modifier = Modifier.padding(start = spacing.sm)
                    )
                }

                is LyricsSourcesState.Failed -> Text(
                    text = state.message,
                    style = AuralisType.bodySmall,
                    color = colors.danger,
                    modifier = Modifier.padding(vertical = spacing.md)
                )

                is LyricsSourcesState.Ready -> {
                    if (state.candidates.isEmpty()) {
                        Text(
                            text = if (state.onlineSearched) {
                                t("No lyrics found for this track.")
                            } else {
                                t("Only this device was searched. Turn on online lyrics in Settings to look further.")
                            },
                            style = AuralisType.bodySmall,
                            color = colors.textSecondary,
                            modifier = Modifier.padding(vertical = spacing.md)
                        )
                    } else {
                        if (!state.onlineSearched) {
                            Text(
                                text = t("Online lyrics are off, so only this device was searched."),
                                style = AuralisType.label,
                                color = colors.textTertiary
                            )
                        }
                        LazyColumn(
                            modifier = Modifier.heightIn(max = 440.dp),
                            verticalArrangement = Arrangement.spacedBy(spacing.sm)
                        ) {
                            items(state.candidates, key = { it.id }) { candidate ->
                                CandidateRow(
                                    candidate = candidate,
                                    persianFont = persianFont,
                                    onClick = { onChoose(candidate, asTranslation) }
                                )
                            }
                        }
                    }
                    Row(
                        modifier = Modifier.padding(top = spacing.xs),
                        horizontalArrangement = Arrangement.spacedBy(spacing.xs)
                    ) {
                        AuralisChip(label = t("Search again"), selected = false) { onRetry() }
                    }
                }
            }
        }
    }
}

@Composable
private fun CandidateRow(
    candidate: LyricsCandidate,
    persianFont: Boolean,
    onClick: () -> Unit
) {
    val colors = AuralisTheme.colors
    val spacing = AuralisTheme.spacing
    val shape = RoundedCornerShape(16.dp)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(colors.surfaceMuted)
            .border(1.dp, colors.outline, shape)
            .combinedClickableCompat(onClick = onClick)
            .padding(spacing.md),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(spacing.md)
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(colors.accentSoft),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = originIcon(candidate.origin),
                contentDescription = null,
                tint = colors.accent,
                modifier = Modifier.size(18.dp)
            )
        }

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                // Known labels are localised; a file name passes through.
                text = t(candidate.sourceLabel),
                style = AuralisType.title,
                color = colors.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (candidate.detail.isNotBlank()) {
                Text(
                    text = t(candidate.detail),
                    style = AuralisType.bodySmall,
                    color = colors.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Text(
                text = candidate.preview,
                style = localizedStyle(AuralisType.bodySmall, candidate.preview, persianFont),
                color = colors.textTertiary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Row(horizontalArrangement = Arrangement.spacedBy(spacing.xs)) {
                Tag(if (candidate.synced) t("Synced") else t("Plain text"))
                Tag(t("%d lines").replace("%d", candidate.lineCount.toString()))
                candidate.language?.let { language ->
                    // Shown with its origin: a file name states the language,
                    // while text analysis can only establish the script.
                    Tag(
                        if (language.fromFileName) language.label
                        else t("%s (detected)").replace("%s", language.label)
                    )
                }
            }
        }
    }
}

@Composable
private fun Tag(text: String) {
    val colors = AuralisTheme.colors
    Text(
        text = text,
        style = AuralisType.label,
        color = colors.textSecondary,
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(colors.surfaceGlass)
            .padding(horizontal = 6.dp, vertical = 2.dp)
    )
}

private fun originIcon(origin: LyricsOrigin): ImageVector = when (origin) {
    LyricsOrigin.SAVED -> Icons.Rounded.Inventory2
    LyricsOrigin.SIDECAR -> Icons.Rounded.Description
    LyricsOrigin.EMBEDDED -> Icons.Rounded.GraphicEq
    LyricsOrigin.ONLINE -> Icons.Rounded.Cloud
}
