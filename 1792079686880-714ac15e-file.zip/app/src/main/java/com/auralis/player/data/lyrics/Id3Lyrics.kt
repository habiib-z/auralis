package com.auralis.player.data.lyrics

import java.io.File
import java.io.RandomAccessFile

/**
 * Minimal reader for lyrics stored *inside* audio files.
 *
 * Android exposes no API for these frames (`MediaMetadataRetriever` has no
 * lyrics key at all), so the tag block is parsed directly:
 *
 *  - MP3 / AAC with an ID3v2 tag: the `USLT` frame (ID3v2.3 and v2.4).
 *  - FLAC / OGG-style Vorbis comments: `LYRICS` or `UNSYNCEDLYRICS`.
 *
 * Only the tag header area is read — never the audio payload — and anything
 * unexpected returns null so the caller can fall back to sidecar files,
 * the online provider or manually entered lyrics.
 */
object Id3Lyrics {

    private const val MAX_TAG_BYTES = 2 * 1024 * 1024
    private const val MAX_FRAME_BYTES = 512 * 1024

    fun read(file: File): String? = RandomAccessFile(file, "r").use { raf ->
        val head = ByteArray(4)
        if (raf.read(head) < 4) return null
        when {
            head[0] == 'I'.code.toByte() && head[1] == 'D'.code.toByte() &&
                head[2] == '3'.code.toByte() -> readId3(raf)
            head[0] == 'f'.code.toByte() && head[1] == 'L'.code.toByte() &&
                head[2] == 'a'.code.toByte() && head[3] == 'C'.code.toByte() -> readFlac(raf)
            else -> null
        }
    }

    // ---- ID3v2 -------------------------------------------------------------

    private fun readId3(raf: RandomAccessFile): String? {
        raf.seek(3)
        val major = raf.read()
        raf.read() // revision
        val flags = raf.read()
        if (major < 0 || flags < 0) return null
        val size = readSyncSafeInt(raf) ?: return null
        if (size <= 0 || size > MAX_TAG_BYTES) return null

        val tag = ByteArray(size)
        if (raf.read(tag) != size) return null

        var offset = 0
        // An extended header, when present, is skipped by its own length.
        if (flags and 0x40 != 0 && size > 4) {
            val extendedSize = beInt(tag, 0)
            if (extendedSize in 1..(size - 4)) offset += extendedSize + 4
        }

        while (offset + 10 <= size) {
            val id = String(tag, offset, 4, Charsets.ISO_8859_1)
            if (id.isBlank() || id[0] == '\u0000') return null
            val frameSize = if (major >= 4) syncSafe(tag, offset + 4) else beInt(tag, offset + 4)
            if (frameSize <= 0 || frameSize > MAX_FRAME_BYTES) return null
            val body = offset + 10
            if (body + frameSize > size) return null
            if (id == "USLT" || id == "ULT") {
                return decodeUslt(tag, body, frameSize)
            }
            offset = body + frameSize
        }
        return null
    }

    /** `USLT` = encoding byte, 3-byte language, description, then the text. */
    private fun decodeUslt(tag: ByteArray, start: Int, length: Int): String? {
        if (length < 5) return null
        val encoding = tag[start].toInt()
        val charset = when (encoding) {
            0 -> Charsets.ISO_8859_1
            1 -> Charsets.UTF_16
            2 -> Charsets.UTF_16BE
            else -> Charsets.UTF_8
        }
        val wide = encoding == 1 || encoding == 2
        var cursor = start + 4 // encoding + language
        val end = start + length
        // Skip the null-terminated description.
        while (cursor < end) {
            if (wide) {
                if (cursor + 1 >= end) return null
                if (tag[cursor] == 0.toByte() && tag[cursor + 1] == 0.toByte()) {
                    cursor += 2
                    break
                }
                cursor += 2
            } else {
                if (tag[cursor] == 0.toByte()) {
                    cursor += 1
                    break
                }
                cursor += 1
            }
        }
        if (cursor >= end) return null
        return String(tag, cursor, end - cursor, charset).trim('\u0000', ' ', '\n', '\r')
            .takeIf { it.isNotBlank() }
    }

    // ---- FLAC Vorbis comments ---------------------------------------------

    private fun readFlac(raf: RandomAccessFile): String? {
        raf.seek(4)
        while (true) {
            val header = ByteArray(4)
            if (raf.read(header) < 4) return null
            val last = header[0].toInt() and 0x80 != 0
            val type = header[0].toInt() and 0x7F
            val length = ((header[1].toInt() and 0xFF) shl 16) or
                ((header[2].toInt() and 0xFF) shl 8) or (header[3].toInt() and 0xFF)
            if (length < 0 || length > MAX_TAG_BYTES) return null
            if (type == 4) {
                val block = ByteArray(length)
                if (raf.read(block) != length) return null
                return parseVorbisComments(block)
            }
            raf.seek(raf.filePointer + length)
            if (last) return null
        }
    }

    private fun parseVorbisComments(block: ByteArray): String? {
        var offset = 0
        fun leInt(): Int? {
            if (offset + 4 > block.size) return null
            val value = (block[offset].toInt() and 0xFF) or
                ((block[offset + 1].toInt() and 0xFF) shl 8) or
                ((block[offset + 2].toInt() and 0xFF) shl 16) or
                ((block[offset + 3].toInt() and 0xFF) shl 24)
            offset += 4
            return value
        }
        val vendorLength = leInt() ?: return null
        if (vendorLength < 0 || offset + vendorLength > block.size) return null
        offset += vendorLength
        val count = leInt() ?: return null
        repeat(count.coerceAtMost(512)) {
            val length = leInt() ?: return null
            if (length < 0 || offset + length > block.size) return null
            val comment = String(block, offset, length, Charsets.UTF_8)
            offset += length
            val separator = comment.indexOf('=')
            if (separator > 0) {
                val key = comment.substring(0, separator).uppercase()
                if (key == "LYRICS" || key == "UNSYNCEDLYRICS" || key == "UNSYNCED LYRICS") {
                    return comment.substring(separator + 1).takeIf { it.isNotBlank() }
                }
            }
        }
        return null
    }

    // ---- helpers -----------------------------------------------------------

    private fun readSyncSafeInt(raf: RandomAccessFile): Int? {
        val bytes = ByteArray(4)
        if (raf.read(bytes) < 4) return null
        return syncSafe(bytes, 0)
    }

    private fun syncSafe(bytes: ByteArray, offset: Int): Int {
        if (offset + 4 > bytes.size) return -1
        return ((bytes[offset].toInt() and 0x7F) shl 21) or
            ((bytes[offset + 1].toInt() and 0x7F) shl 14) or
            ((bytes[offset + 2].toInt() and 0x7F) shl 7) or
            (bytes[offset + 3].toInt() and 0x7F)
    }

    private fun beInt(bytes: ByteArray, offset: Int): Int {
        if (offset + 4 > bytes.size) return -1
        return ((bytes[offset].toInt() and 0xFF) shl 24) or
            ((bytes[offset + 1].toInt() and 0xFF) shl 16) or
            ((bytes[offset + 2].toInt() and 0xFF) shl 8) or
            (bytes[offset + 3].toInt() and 0xFF)
    }
}
