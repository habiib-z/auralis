package com.auralis.player.ui.i18n

import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable

/**
 * Translation table for the long-form copy that is not worth a field in
 * [Strings]: settings labels, descriptions and transient user messages.
 *
 * The English text is the key, so an untranslated string renders exactly as it
 * did before instead of showing a placeholder. Add a Persian entry to localise
 * it — nothing else has to change at the call site.
 */
object Copy {

    fun translate(strings: Strings, english: String): String =
        if (strings.rtl) FA[english] ?: english else english

    private val FA: Map<String, String> = mapOf(
        // ---- sleep timer & speed -------------------------------------------
        "Sleep timer" to "تایمر خواب",
        "Stops at the end of this track" to "در پایان همین آهنگ متوقف می‌شود",
        "Running — fades out and pauses when it reaches zero" to
            "در حال اجرا — در پایان، صدا محو و پخش متوقف می‌شود",
        "Drag the dial, or pick a preset" to "حلقه را بکشید یا یک گزینهٔ آماده انتخاب کنید",
        "remaining" to "باقی‌مانده",
        "minutes" to "دقیقه",
        "Stop at end of track" to "توقف در پایان آهنگ",
        "Finish this song, then pause" to "همین آهنگ تمام شود، بعد مکث",
        "Update timer" to "به‌روزرسانی تایمر",
        "Start timer" to "شروع تایمر",
        "Cancel" to "لغو",
        "Playback speed" to "سرعت پخش",
        "Pitch is preserved · remembered across sessions" to "زیروبمی حفظ می‌شود · ذخیره می‌ماند",
        "Reset to normal" to "بازگشت به حالت عادی",
        // ---- multi-select ---------------------------------------------------
        "Cancel selection" to "لغو انتخاب",
        "%d selected" to "%d انتخاب‌شده",
        "All" to "همه",
        "None" to "هیچ‌کدام",
        "Play" to "پخش",
        "Shuffle" to "تصادفی",
        "Play next" to "پخش بعدی",
        "Add to queue" to "افزودن به صف",
        "Add to playlist" to "افزودن به پلی‌لیست",
        "Favorite" to "علاقه‌مندی",
        "Share" to "اشتراک‌گذاری",
        "Delete" to "حذف",
        "%d tracks play next" to "%d آهنگ بعدی پخش می‌شود",
        "%d tracks added to favorites" to "%d آهنگ به علاقه‌مندی‌ها اضافه شد",
        "%d tracks removed from favorites" to "%d آهنگ از علاقه‌مندی‌ها حذف شد",
        "%d tracks deleted" to "%d آهنگ حذف شد",
        // ---- settings hub -------------------------------------------------
        "Appearance" to "ظاهر",
        // ---- about ---------------------------------------------------------
        "Privacy & About" to "حریم خصوصی و درباره",
        "Offline-first, source code, version" to "آفلاین، سورس‌کد، نسخه",
        "PRIVACY" to "حریم خصوصی",
        "VERSION" to "نسخه",
        "PROJECT" to "پروژه",
        "Auralis is offline-first. There is no account, no analytics and no background " +
            "upload. Your library, statistics and settings never leave this device." to
            "اورالیس آفلاین کار می‌کند؛ نه حساب کاربری دارد، نه آمارگیری و نه آپلود پس‌زمینه. " +
            "کتابخانه، آمار و تنظیمات شما هرگز از این دستگاه خارج نمی‌شود.",
        "Open source. Built and maintained by habiib-z." to
            "متن‌باز. ساخته و نگهداری‌شده توسط habiib-z.",
        "Source code" to "سورس‌کد",
        "Developer" to "توسعه‌دهنده",
        "Mode, accent, layout" to "حالت، رنگ تأکید، چیدمان",
        "Playback" to "پخش",
        "Gapless, crossfade, speed, repeat" to "محو تدریجی، سرعت، تکرار",
        "Audio & Effects" to "صدا و افکت‌ها",
        "Equalizer, bass, balance, visualizer" to "اکولایزر، بیس، بالانس، نمایشگر",
        "Library" to "کتابخانه",
        "Scanning, folders, defaults" to "اسکن، پوشه‌ها، پیش‌فرض‌ها",
        "Lyrics" to "متن ترانه",
        "Embedded and online lookup" to "متن داخل فایل و جست‌وجوی آنلاین",
        "Notifications" to "اعلان‌ها",
        "Media controls and artwork" to "کنترل‌های پخش و کاور",
        "Backup & Restore" to "پشتیبان‌گیری و بازیابی",
        "Encrypted export of your data" to "خروجی گرفتن از داده‌های شما",
        "Settings" to "تنظیمات",
        "Back to settings" to "بازگشت به تنظیمات",

        // ---- appearance ---------------------------------------------------
        "THEME STUDIO" to "استودیوی پوسته",
        "MODE" to "حالت",
        "System" to "سیستم",
        "Light" to "روشن",
        "Dark" to "تاریک",
        "START SCREEN" to "صفحه شروع",
        "Which page opens when you launch the app" to "وقتی برنامه را باز می‌کنید کدام صفحه نمایش داده شود",
        "Home" to "خانه",
        "Playlists" to "پلی‌لیست‌ها",
        "Likes" to "علاقه‌مندی‌ها",
        "ACCENT" to "رنگ تأکید",
        "Accent follows your wallpaper (Android 12+) or the current artwork." to
            "رنگ تأکید از تصویر زمینه (اندروید ۱۲+) یا کاور آهنگ گرفته می‌شود.",
        "Custom accent" to "رنگ دلخواه",
        "Hue" to "رنگ",
        "Saturation" to "اشباع",
        "Brightness" to "روشنایی",
        "Selected" to "انتخاب‌شده",
        "LAYOUT" to "چیدمان",
        "List" to "فهرست",
        "Grid" to "شبکه",
        "Animations" to "انیمیشن‌ها",
        "Motion across the whole app" to "حرکت در کل برنامه",
        "Haptic feedback" to "بازخورد لرزشی",
        "Tiny taps on interactions" to "لرزش‌های کوچک هنگام لمس",
        "LANGUAGE" to "زبان",

        // ---- playback -----------------------------------------------------
        "ENGINE" to "موتور پخش",
        "Fade between tracks" to "محو شدن بین آهنگ‌ها",
        "Off" to "خاموش",
        "Fades the end of a track out and the start of the next one in. A single player cannot overlap two tracks, so this is a fade, not a true crossfade." to
            "پایان هر آهنگ محو می‌شود و ابتدای آهنگ بعدی کم‌کم بالا می‌آید. یک پلیر نمی‌تواند دو آهنگ را هم‌پوشان کند، پس این محو تدریجی است نه کراسفید واقعی.",
        "Keep pitch when changing speed" to "حفظ زیر و بمی هنگام تغییر سرعت",
        "Off sounds like an old tape deck" to "خاموش، صدا شبیه نوار کاست قدیمی می‌شود",
        "Skip silence" to "رد کردن سکوت",
        "Trim silent passages inside and between tracks" to "حذف بخش‌های بی‌صدا داخل و بین آهنگ‌ها",
        "Loudness normalization" to "یکسان‌سازی بلندی صدا",
        "Lifts quiet tracks toward the target loudness below" to "آهنگ‌های کم‌صدا را به بلندی هدف پایین نزدیک می‌کند",
        "BEHAVIOR" to "رفتار",
        "Repeat" to "تکرار",
        "One" to "یکی",
        "Resume playback on start" to "ادامه پخش در شروع برنامه",
        "Respect audio focus" to "احترام به تمرکز صدا",
        "Pause when another app plays audio" to "وقتی برنامه دیگری صدا پخش می‌کند، متوقف شود",
        "Long-press seek amount" to "مقدار جابه‌جایی با نگه داشتن",
        "How far holding next / previous skips in the player" to
            "نگه داشتن دکمه بعدی/قبلی چقدر در آهنگ جلو یا عقب برود",
        "HEADPHONES & BLUETOOTH" to "هدفون و بلوتوث",
        "Play on connect" to "پخش هنگام اتصال",
        "Start playing when headphones or a car stereo connect" to
            "وقتی هدفون یا ضبط خودرو وصل شد، پخش شروع شود",
        "Pause on disconnect" to "توقف هنگام قطع اتصال",
        "Never blast music out of the phone speaker by accident" to
            "تا موسیقی ناخواسته از بلندگوی گوشی پخش نشود",
        "Resume on reconnect" to "ادامه پخش هنگام اتصال مجدد",
        "Pick the track back up when the same device comes back" to
            "با برگشت همان دستگاه، آهنگ از همان‌جا ادامه یابد",
        "DRIVE MODE" to "حالت رانندگی",
        "A stripped-back, glanceable player with oversized controls for the car" to
            "پلیری ساده با دکمه‌های بزرگ، مناسب رانندگی",
        "Show lyric line" to "نمایش خط ترانه",
        "One large synced line, when lyrics exist" to "یک خط بزرگ هم‌زمان، وقتی متن موجود باشد",
        "Keep screen on" to "روشن ماندن صفحه",
        "Prevent the display from sleeping in Drive Mode" to "در حالت رانندگی صفحه خاموش نشود",
        "Swipe to change track" to "کشیدن برای تغییر آهنگ",
        "Swipe anywhere left or right instead of aiming for a button" to
            "هر جای صفحه را چپ یا راست بکشید، نیازی به زدن دکمه نیست",
        "Skip buttons" to "دکمه‌های جابه‌جایی",

        // ---- audio --------------------------------------------------------
        "EQUALIZER" to "اکولایزر",
        "Equalizer enabled" to "اکولایزر فعال",
        "Bands" to "باندها",
        "5 band" to "۵ باند",
        "10 band" to "۱۰ باند",
        "TONE" to "تنالیته",
        "Bass boost" to "تقویت بیس",
        "Treble" to "تیز",
        "Volume" to "بلندی صدا",
        "Player volume; use loudness normalization to lift quiet tracks" to
            "بلندی پلیر؛ برای بلندتر کردن آهنگ‌های کم‌صدا از یکسان‌سازی بلندی استفاده کنید",
        "Backup files are scrambled with a key built into the app, not with a password of yours. Treat an .aur file as readable by anyone who has it and this app — keep it somewhere you trust." to
            "فایل‌های پشتیبان با کلیدی که داخل خود برنامه است مخفی می‌شوند، نه با رمز شما. فرض کنید هر کسی که فایل .aur و این برنامه را داشته باشد می‌تواند آن را بخواند؛ پس جای مطمئنی نگه دارید.",
        "Export and restore your data" to "خروجی گرفتن و بازیابی داده‌ها",
        "Balance" to "بالانس",
        "Center" to "وسط",
        "Mono audio" to "صدای مونو",
        "Fold both channels into one — for listening with one ear or one earbud" to
            "ترکیب دو کانال در یکی — برای شنیدن با یک گوش یا یک ایربد",
        "LOUDNESS & SPACE" to "بلندی و فضا",
        "Target loudness" to "بلندی هدف",
        "Reverb" to "پژواک",
        "Small room" to "اتاق کوچک",
        "Medium room" to "اتاق متوسط",
        "Large room" to "اتاق بزرگ",
        "Medium hall" to "سالن متوسط",
        "Large hall" to "سالن بزرگ",
        "Plate" to "صفحه‌ای",
        "VISUALIZER" to "نمایشگر صدا",
        "Sensitivity" to "حساسیت",
        "Smoothing" to "نرمی",
        "Intensity" to "شدت",
        "Bars" to "تعداد میله‌ها",

        // ---- library ------------------------------------------------------
        "SCANNING" to "اسکن",
        "Rescan library" to "اسکن مجدد کتابخانه",
        "Look for new and removed tracks" to "جست‌وجوی آهنگ‌های جدید و حذف‌شده",
        "Folder browser" to "مرور پوشه‌ها",
        "Browse and exclude folders" to "مرور و نادیده گرفتن پوشه‌ها",
        "Listening statistics" to "آمار شنیدن",
        "Your most played music" to "پرپخش‌ترین موسیقی شما",
        "Ignore tracks shorter than" to "نادیده گرفتن آهنگ‌های کوتاه‌تر از",
        "DEFAULTS" to "پیش‌فرض‌ها",
        "Start tab" to "تب شروع",
        "Sort order" to "ترتیب چینش",
        "EXCLUDED FOLDERS" to "پوشه‌های نادیده‌گرفته‌شده",
        "None — everything on the device is scanned." to "هیچ‌کدام — همه دستگاه اسکن می‌شود.",

        // ---- lyrics -------------------------------------------------------
        "Embedded lyrics" to "متن داخل فایل",
        "Read lyrics stored inside audio files" to "خواندن متن ذخیره‌شده در فایل صوتی",
        "Online lyrics lookup" to "جست‌وجوی آنلاین متن",
        "Auto search when missing" to "جست‌وجوی خودکار وقتی متن نیست",
        "Floating lyrics on player" to "متن شناور روی پلیر",
        "SoundCloud-style synced line that comes and goes over the player" to
            "یک خط هم‌زمان که روی پلیر ظاهر و محو می‌شود",
        "APPEARANCE" to "ظاهر",
        "These preview live on the lyrics panel in the player." to
            "این تنظیمات هم‌زمان روی پنل متن در پلیر دیده می‌شوند.",
        "Font size" to "اندازه قلم",
        "Line spacing" to "فاصله خطوط",
        "Alignment" to "تراز",
        "Start" to "آغاز",
        "End" to "پایان",
        "Bold active line" to "پررنگ کردن خط فعال",
        "Emphasise the line being sung" to "خطی که خوانده می‌شود برجسته شود",
        "Persian font (Vazir)" to "قلم فارسی (وزیر)",
        "Use Vazir for Persian lyrics and titles" to "استفاده از وزیر برای متن و عنوان فارسی",
        "Inactive line opacity" to "شفافیت خطوط غیرفعال",
        "TRANSLATION" to "ترجمه",
        "Show translation" to "نمایش ترجمه",
        "Display translation under the original line" to "نمایش ترجمه زیر خط اصلی",
        "Translation size" to "اندازه ترجمه",
        "Gap above translation" to "فاصله بالای ترجمه",

        // ---- notifications ------------------------------------------------
        "Artwork in notification" to "کاور در اعلان",
        "Shown on the lock screen and in the notification shade" to
            "در صفحه قفل و کشوی اعلان‌ها نمایش داده می‌شود",

        // ---- backup -------------------------------------------------------
        "MANUAL" to "دستی",
        "Export backup" to "خروجی پشتیبان",
        "Favorites, pinned songs, playlists and theme" to
            "علاقه‌مندی‌ها، آهنگ‌های سنجاق‌شده، پلی‌لیست‌ها و پوسته",
        "Restore backup" to "بازیابی پشتیبان",
        "Pick an .aur file exported earlier" to "یک فایل .aur که قبلاً ساخته‌اید انتخاب کنید",
        "AUTOMATIC" to "خودکار",
        "Daily auto backup" to "پشتیبان‌گیری خودکار روزانه",
        "Runs when you open the app, keeps the last 7 files" to
            "هنگام باز کردن برنامه اجرا می‌شود و ۷ فایل آخر را نگه می‌دارد",
        "Stored in the app's private folder (Android/data). Use manual export for a copy that survives uninstalling." to
            "در پوشه خصوصی برنامه (Android/data) ذخیره می‌شود. برای نسخه‌ای که پس از حذف برنامه باقی بماند، خروجی دستی بگیرید.",

        // ---- privacy ------------------------------------------------------

        // ---- transient messages -------------------------------------------
        "Auralis needs audio access to build your library" to
            "برای ساختن کتابخانه، Auralis به دسترسی صدا نیاز دارد",
        "Grant audio access first" to "اول دسترسی صدا را بدهید",
        "That track is no longer in your library" to "آن آهنگ دیگر در کتابخانه نیست",
        "Added to queue" to "به صف پخش اضافه شد",
        "Removed from favorites" to "از علاقه‌مندی‌ها حذف شد",
        "Added to favorites" to "به علاقه‌مندی‌ها اضافه شد",
        "Tags saved" to "اطلاعات ذخیره شد",
        "Set as ringtone" to "به‌عنوان زنگ تنظیم شد",
        "Ringtone set" to "زنگ تنظیم شد",
        "Backup saved" to "پشتیبان ذخیره شد",

        // ---- lyrics source chooser -----------------------------------------
        "Choose lyrics" to "انتخاب متن ترانه",
        "Versions found for this track. Pick the one you want to see." to
            "نسخه‌های پیداشده برای این آهنگ. هرکدام را می‌خواهید انتخاب کنید.",
        "As lyrics" to "به‌عنوان متن اصلی",
        "As translation" to "به‌عنوان ترجمه",
        "Looking for versions…" to "در حال جست‌وجوی نسخه‌ها…",
        "No lyrics found for this track." to "برای این آهنگ متنی پیدا نشد.",
        "Only this device was searched. Turn on online lyrics in Settings to look further." to
            "فقط همین دستگاه جست‌وجو شد. برای جست‌وجوی بیشتر، متن آنلاین را در تنظیمات روشن کنید.",
        "Online lyrics are off, so only this device was searched." to
            "متن آنلاین خاموش است، پس فقط همین دستگاه جست‌وجو شد.",
        "Search again" to "جست‌وجوی دوباره",
        "Synced" to "هم‌زمان‌شده",
        "Plain text" to "متن ساده",
        "%d lines" to "%d خط",
        "%s (detected)" to "%s (تشخیص خودکار)",
        "Choose lyrics source" to "انتخاب منبع متن ترانه",
        "Choose source" to "انتخاب منبع",
        "Saved in Auralis" to "ذخیره‌شده در Auralis",
        "Saved translation" to "ترجمهٔ ذخیره‌شده",
        "Embedded in the file" to "داخل خود فایل",
        "File next to the track" to "فایل کنار آهنگ",
        "Couldn't save that version" to "ذخیرهٔ آن نسخه ممکن نشد"
    )
}

/** Composable shorthand: `t("Skip silence")`. */
@Composable
@ReadOnlyComposable
fun t(english: String): String = Copy.translate(LocalStrings.current, english)
