package com.auralis.player.data.lyrics

/** Where a lyrics candidate came from. */
enum class LyricsOrigin { SAVED, SIDECAR, EMBEDDED, ONLINE }

/**
 * One concrete lyrics payload the user can choose.
 *
 * A track often has several: a file saved earlier, an `.lrc` next to the
 * audio, a translation sidecar in another language, the tag inside the file,
 * and a handful of online matches. Instead of silently picking the first one,
 * every candidate is offered with enough detail to tell them apart.
 */
data class LyricsCandidate(
    val id: String,
    val origin: LyricsOrigin,
    /** Short provenance, for example a file name or the provider name. */
    val sourceLabel: String,
    /** Second line of detail: album and duration for online matches. */
    val detail: String = "",
    /** Script/language tag when it can be established, otherwise null. */
    val language: LyricsLanguage? = null,
    val synced: Boolean,
    val lineCount: Int,
    /** First lines, for a glance before committing. */
    val preview: String,
    val text: String
)

/**
 * A language label with an honest confidence.
 *
 * Only the writing system can be read reliably from the text itself, and a
 * file name suffix such as `song.fa.lrc` is a direct statement of intent. Both
 * are reported for what they are; nothing here guesses between languages that
 * share a script.
 */
data class LyricsLanguage(val code: String, val label: String, val fromFileName: Boolean)

object LyricsLanguages {

    private val NAMES = mapOf(
        "fa" to "Persian", "ar" to "Arabic", "en" to "English", "tr" to "Turkish",
        "ru" to "Russian", "es" to "Spanish", "fr" to "French", "de" to "German",
        "it" to "Italian", "pt" to "Portuguese", "nl" to "Dutch", "sv" to "Swedish",
        "ja" to "Japanese", "ko" to "Korean", "zh" to "Chinese", "hi" to "Hindi",
        "he" to "Hebrew", "el" to "Greek", "ur" to "Urdu", "ku" to "Kurdish",
        "az" to "Azerbaijani", "hy" to "Armenian", "ka" to "Georgian", "th" to "Thai"
    )

    /** Maps a file-name suffix such as `fa`, `per`, `fas`, `translation`. */
    fun fromSuffix(suffix: String): LyricsLanguage? {
        val key = suffix.lowercase().trim()
        val code = when (key) {
            "per", "fas", "farsi", "persian" -> "fa"
            "ara", "arabic" -> "ar"
            "eng", "english" -> "en"
            "tur", "turkish" -> "tr"
            "rus", "russian" -> "ru"
            "translation", "trans", "tr2" -> return LyricsLanguage("", "Translation", true)
            else -> key
        }
        val name = NAMES[code] ?: return null
        return LyricsLanguage(code, name, fromFileName = true)
    }

    /**
     * Reads the dominant writing system. Scripts used by several languages are
     * reported as the script, not as a guessed language, because the text
     * alone does not carry that information.
     */
    fun fromText(text: String): LyricsLanguage? {
        var arabic = 0
        var persianOnly = 0
        var cyrillic = 0
        var cjk = 0
        var hangul = 0
        var kana = 0
        var hebrew = 0
        var greek = 0
        var latin = 0
        var total = 0
        for (ch in text) {
            if (!ch.isLetter()) continue
            total++
            when (ch.code) {
                in 0x0600..0x06FF, in 0x0750..0x077F, in 0xFB50..0xFDFF -> {
                    arabic++
                    // Letters that exist in Persian but not in Arabic.
                    if (ch in "\u067E\u0686\u0698\u06AF\u06CC\u06A9") persianOnly++
                }
                in 0x0400..0x04FF -> cyrillic++
                in 0x3040..0x30FF -> kana++
                in 0x4E00..0x9FFF -> cjk++
                in 0xAC00..0xD7AF -> hangul++
                in 0x0590..0x05FF -> hebrew++
                in 0x0370..0x03FF -> greek++
                in 0x0041..0x024F -> latin++
            }
            if (total > 4000) break
        }
        if (total < 8) return null
        return when (maxOf(arabic, cyrillic, cjk, hangul, kana, hebrew, greek, latin)) {
            0 -> null
            arabic -> if (persianOnly >= 3) {
                LyricsLanguage("fa", "Persian", false)
            } else {
                LyricsLanguage("ar", "Arabic script", false)
            }
            kana -> LyricsLanguage("ja", "Japanese", false)
            hangul -> LyricsLanguage("ko", "Korean", false)
            cjk -> LyricsLanguage("zh", "Chinese characters", false)
            cyrillic -> LyricsLanguage("ru", "Cyrillic script", false)
            hebrew -> LyricsLanguage("he", "Hebrew", false)
            greek -> LyricsLanguage("el", "Greek", false)
            latin -> LyricsLanguage("la", "Latin script", false)
            else -> null
        }
    }
}
