package com.auralis.player.data.lyrics

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.auralis.player.data.db.SongDao
import com.auralis.player.domain.model.LyricLine
import com.auralis.player.domain.model.Lyrics
import com.auralis.player.domain.model.Song
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import javax.inject.Inject
import javax.inject.Singleton

/** Editable lyrics payload shown in the in-app lyrics editor. */
data class RawLyrics(val text: String, val translation: String)

/** Outcome of an explicit online lyrics download. */
sealed class LyricsFetchResult {
    /** Lyrics were downloaded and saved (or were already saved). */
    data class Success(val lyrics: Lyrics, val alreadySaved: Boolean) : LyricsFetchResult()
    /** The provider returned no lyrics for this track. */
    data object NotFound : LyricsFetchResult()
    /** No internet connection — cached lyrics (if any) remain usable. */
    data object Offline : LyricsFetchResult()
    /** A network / parsing error occurred. */
    data class Error(val message: String) : LyricsFetchResult()
}

@Singleton
class LyricsRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val songDao: SongDao
) {

    /** Tracks the provider has no lyrics for, so they are asked about once. */
    private val notFound = HashSet<String>()

    private companion object {
        /** Enough to choose from without turning the sheet into a list to scroll. */
        const val MAX_ONLINE_RESULTS = 8
    }

    /**
     * Resolves the best available lyrics for a song, including any translation.
     * Order: cached in DB → sidecar files → embedded tag → (optional) online.
     * Anything found is cached back into the DB so it also works offline later.
     */
    suspend fun lyricsFor(
        song: Song,
        allowOnline: Boolean,
        allowEmbedded: Boolean = true
    ): Lyrics? = withContext(Dispatchers.IO) {
        val translation = translationFor(song)

        val mainText: String? = run {
            song.lyrics?.takeIf { it.isNotBlank() }?.let { return@run it }

            sidecarFile(song)?.let { file ->
                val text = runCatching { file.readText() }.getOrNull()
                if (!text.isNullOrBlank()) {
                    songDao.updateLyrics(song.id, text)
                    return@run text
                }
            }

            if (allowEmbedded) {
                embedded(song)?.let { text ->
                    songDao.updateLyrics(song.id, text)
                    return@run text
                }
            }

            if (allowOnline && isOnline()) {
                fetchOnline(song)?.let { text ->
                    songDao.updateLyrics(song.id, text)
                    return@run text
                }
            }
            null
        }
        val resolvedText = mainText ?: return@withContext null

        val parsed = LyricsParser.parse(resolvedText)
        parsed.copy(
            translationLines = translation?.let { LyricsParser.parse(it).lines } ?: emptyList(),
            translationPlainText = translation?.takeIf { LyricsParser.parse(it).lines.isEmpty() }
        )
    }

    /** True when a lyrics payload is already cached locally for offline use. */
    fun hasCached(song: Song): Boolean =
        !song.lyrics.isNullOrBlank() || sidecarFile(song) != null

    /**
     * Explicit user-triggered download. Distinguishes offline, not-found and
     * already-saved so the UI can give precise feedback instead of failing
     * silently. Requires connectivity; cached lyrics are returned when present.
     */
    suspend fun downloadOnline(song: Song): LyricsFetchResult = withContext(Dispatchers.IO) {
        if (!isOnline()) {
            // Cached lyrics remain perfectly usable offline.
            song.lyrics?.takeIf { it.isNotBlank() }?.let {
                val parsed = LyricsParser.parse(it)
                return@withContext LyricsFetchResult.Success(parsed, alreadySaved = true)
            }
            return@withContext LyricsFetchResult.Offline
        }

        val text = try {
            fetchOnline(song)
        } catch (t: Throwable) {
            return@withContext LyricsFetchResult.Error(t.message ?: "Download failed")
        }

        if (text.isNullOrBlank()) return@withContext LyricsFetchResult.NotFound

        songDao.updateLyrics(song.id, text)
        val translation = translationFor(song)
        val parsed = LyricsParser.parse(text).copy(
            translationLines = translation?.let { LyricsParser.parse(it).lines } ?: emptyList(),
            translationPlainText = translation?.takeIf { LyricsParser.parse(it).lines.isEmpty() }
        )
        LyricsFetchResult.Success(parsed, alreadySaved = false)
    }

    // ---- multiple sources ---------------------------------------------------

    /**
     * Every lyrics payload available for [song], so the user can choose rather
     * than accept whatever the resolver happened to rank first.
     *
     * Local sources are always collected. Online matches are added only when
     * the caller allows it, and a match is never saved as a side effect of
     * looking: nothing is written until [applyCandidate] is called.
     */
    suspend fun candidatesFor(
        song: Song,
        allowOnline: Boolean,
        allowEmbedded: Boolean = true
    ): List<LyricsCandidate> = withContext(Dispatchers.IO) {
        val out = ArrayList<LyricsCandidate>()
        val seen = HashSet<String>()

        fun add(candidate: LyricsCandidate) {
            val fingerprint = candidate.text.filterNot { it.isWhitespace() }.take(400)
            if (fingerprint.isEmpty() || !seen.add(fingerprint)) return
            out += candidate
        }

        song.lyrics?.takeIf { it.isNotBlank() }?.let {
            add(describe("saved", LyricsOrigin.SAVED, "Saved in Auralis", "", null, it))
        }
        song.lyricsTranslation?.takeIf { it.isNotBlank() }?.let {
            add(describe("saved-translation", LyricsOrigin.SAVED, "Saved translation", "", null, it))
        }

        sidecarFiles(song).forEach { (file, suffix) ->
            val text = runCatching { file.readText() }.getOrNull()
            if (!text.isNullOrBlank()) {
                add(
                    describe(
                        id = "file:${file.absolutePath}",
                        origin = LyricsOrigin.SIDECAR,
                        sourceLabel = file.name,
                        detail = "File next to the track",
                        hinted = suffix?.let { LyricsLanguages.fromSuffix(it) },
                        text = text
                    )
                )
            }
        }

        if (allowEmbedded) {
            embedded(song)?.let {
                add(describe("embedded", LyricsOrigin.EMBEDDED, "Embedded in the file", "ID3 / Vorbis tag", null, it))
            }
        }

        if (allowOnline && isOnline()) {
            runCatching { searchOnline(song) }.getOrNull()?.forEach(::add)
        }

        out
    }

    /**
     * Stores a chosen candidate as the track's lyrics, or as its translation
     * when [asTranslation] is set. Picking one language as the main text and
     * another as the translation is the point of having both.
     */
    suspend fun applyCandidate(
        songId: Long,
        candidate: LyricsCandidate,
        asTranslation: Boolean
    ) = withContext(Dispatchers.IO) {
        if (asTranslation) {
            songDao.updateLyricsTranslation(songId, candidate.text)
        } else {
            songDao.updateLyrics(songId, candidate.text)
        }
    }

    private fun describe(
        id: String,
        origin: LyricsOrigin,
        sourceLabel: String,
        detail: String,
        hinted: LyricsLanguage?,
        text: String
    ): LyricsCandidate {
        val parsed = LyricsParser.parse(text)
        val plain = parsed.lines.joinToString("\n") { it.text }.ifBlank { text }
        return LyricsCandidate(
            id = id,
            origin = origin,
            sourceLabel = sourceLabel,
            detail = detail,
            // A file name suffix states the language outright; otherwise the
            // writing system is all the text can honestly tell us.
            language = hinted ?: LyricsLanguages.fromText(plain),
            synced = parsed.synchronized,
            lineCount = parsed.lines.count { it.text.isNotBlank() },
            preview = plain.lineSequence().filter { it.isNotBlank() }.take(3).joinToString(" / ").take(140),
            text = text
        )
    }

    /**
     * Every `.lrc` / `.txt` sitting next to the audio file whose name starts
     * with the track's base name, paired with the suffix in between, so
     * `song.fa.lrc` reports `fa`.
     */
    private fun sidecarFiles(song: Song): List<Pair<File, String?>> {
        if (!song.path.startsWith("/")) return emptyList()
        val audio = File(song.path)
        val dir = audio.parentFile ?: return emptyList()
        val base = audio.name.substringBeforeLast('.', audio.name)
        val files = runCatching { dir.listFiles() }.getOrNull() ?: return emptyList()
        return files
            .filter { it.isFile && it.canRead() }
            .filter { it.name.startsWith("$base.", ignoreCase = true) }
            .filter { it.extension.equals("lrc", true) || it.extension.equals("txt", true) }
            .sortedBy { it.name }
            .map { file ->
                val middle = file.name
                    .removePrefix("$base.")
                    .substringBeforeLast('.', "")
                    .takeIf { it.isNotBlank() }
                file to middle
            }
    }

    /**
     * lrclib search. Unlike the single `get` call this returns several matches
     * for the same track, which is exactly what the chooser needs. Synced and
     * plain versions of one match are listed separately because they are
     * genuinely different payloads.
     */
    private fun searchOnline(song: Song): List<LyricsCandidate> {
        val query = buildString {
            append("track_name=").append(URLEncoder.encode(song.title, "UTF-8"))
            if (song.displayArtist.isNotBlank()) {
                append("&artist_name=").append(URLEncoder.encode(song.displayArtist, "UTF-8"))
            }
        }
        val connection = (URL("https://lrclib.net/api/search?$query").openConnection()
            as HttpURLConnection).apply {
            connectTimeout = 6_000
            readTimeout = 8_000
            setRequestProperty("User-Agent", "Auralis/1.0 (https://github.com/habiib-z)")
            setRequestProperty("Accept", "application/json")
        }
        val body = try {
            if (connection.responseCode !in 200..299) return emptyList()
            connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            runCatching { connection.disconnect() }
        }

        val array = runCatching { JSONArray(body) }.getOrNull() ?: return emptyList()
        val results = ArrayList<LyricsCandidate>()
        for (i in 0 until minOf(array.length(), MAX_ONLINE_RESULTS)) {
            val item = array.optJSONObject(i) ?: continue
            val trackName = item.optString("trackName")
            val artistName = item.optString("artistName")
            val albumName = item.optString("albumName")
            val seconds = item.optInt("duration", 0)
            val detail = listOf(
                listOf(trackName, artistName).filter { it.isNotBlank() }.joinToString(" · "),
                albumName.takeIf { it.isNotBlank() }.orEmpty(),
                if (seconds > 0) "%d:%02d".format(seconds / 60, seconds % 60) else ""
            ).filter { it.isNotBlank() }.joinToString(" · ")

            item.optString("syncedLyrics").takeIf { it.isNotBlank() }?.let {
                results += describe("lrclib-synced-$i", LyricsOrigin.ONLINE, "lrclib", detail, null, it)
            }
            item.optString("plainLyrics").takeIf { it.isNotBlank() }?.let {
                results += describe("lrclib-plain-$i", LyricsOrigin.ONLINE, "lrclib", detail, null, it)
            }
        }
        return results
    }

    /** Saves (or clears with null) the main lyrics for a song. */
    suspend fun save(songId: Long, text: String?) = withContext(Dispatchers.IO) {
        songDao.updateLyrics(songId, text?.takeIf { it.isNotBlank() })
    }

    /** Saves (or clears with null) the translation for a song. */
    suspend fun saveTranslation(songId: Long, text: String?) = withContext(Dispatchers.IO) {
        songDao.updateLyricsTranslation(songId, text?.takeIf { it.isNotBlank() })
    }

    /** Raw stored/derived lyrics + translation text, for the in-app editor. */
    suspend fun rawFor(song: Song): RawLyrics = withContext(Dispatchers.IO) {
        val main = song.lyrics?.takeIf { it.isNotBlank() }
            ?: sidecarFile(song)?.let { runCatching { it.readText() }.getOrNull() }
            ?: embedded(song)
        RawLyrics(main.orEmpty(), translationFor(song).orEmpty())
    }

    /** True if the device currently has a usable internet connection. */
    private fun isOnline(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    private fun sidecarFile(song: Song): File? {
        if (!song.path.startsWith("/")) return null
        val base = song.path.substringBeforeLast('.', song.path)
        return listOf("$base.lrc", "$base.txt")
            .map(::File)
            .firstOrNull { it.exists() && it.canRead() }
    }

    /**
     * Looks for a translation sidecar next to the audio file. Supported names
     * for `/x/song.mp3`: `song.fa.lrc`, `song.translation.lrc`, `song.per.lrc`,
     * `song.ar.lrc`, `song.fa.txt`, `song.translation.txt`.
     */
    private fun translationFor(song: Song): String? {
        song.lyricsTranslation?.takeIf { it.isNotBlank() }?.let { return it }
        if (!song.path.startsWith("/")) return null
        val base = song.path.substringBeforeLast('.', song.path)
        val candidates = listOf(
            "$base.fa.lrc", "$base.translation.lrc", "$base.per.lrc", "$base.ar.lrc",
            "$base.fa.txt", "$base.translation.txt"
        )
        val file = candidates.map(::File).firstOrNull { it.exists() && it.canRead() } ?: return null
        return runCatching { file.readText() }.getOrNull()?.takeIf { it.isNotBlank() }
    }

    /**
     * Embedded lyrics.
     *
     * The platform has no API for the ID3 `USLT` / Vorbis `LYRICS` frames, and
     * the previous implementation read `METADATA_KEY_WRITER` (the songwriter
     * field) and showed whatever happened to contain a newline. That produced
     * wrong text, so it is gone: only the real frame is read, by scanning the
     * tag block of the file itself. Anything unparsable yields null and the
     * sidecar / online / manual paths take over.
     */
    private fun embedded(song: Song): String? {
        val path = song.path.takeIf { it.startsWith("/") } ?: return null
        val file = File(path)
        if (!file.exists() || !file.canRead()) return null
        return runCatching { Id3Lyrics.read(file) }.getOrNull()?.takeIf { it.isNotBlank() }
    }

    /**
     * Opt-in only: nothing leaves the device unless the user enables online
     * lyrics. Album and duration are included because lrclib matches far more
     * accurately with them, the HTTP status is checked instead of assumed, and
     * a miss is remembered so the same track is not requested over and over.
     */
    private fun fetchOnline(song: Song): String? {
        val cacheKey = "${song.displayArtist}|${song.title}|${song.durationMs / 1000}"
        synchronized(notFound) { if (cacheKey in notFound) return null }

        val query = buildString {
            append("artist_name=").append(URLEncoder.encode(song.displayArtist, "UTF-8"))
            append("&track_name=").append(URLEncoder.encode(song.title, "UTF-8"))
            if (song.displayAlbum.isNotBlank()) {
                append("&album_name=").append(URLEncoder.encode(song.displayAlbum, "UTF-8"))
            }
            if (song.durationMs > 0) append("&duration=").append(song.durationMs / 1000)
        }

        val result = runCatching {
            val connection = (URL("https://lrclib.net/api/get?$query").openConnection()
                as HttpURLConnection).apply {
                connectTimeout = 6_000
                readTimeout = 6_000
                setRequestProperty("User-Agent", "Auralis/1.0 (https://github.com/auralis)")
                setRequestProperty("Accept", "application/json")
            }
            try {
                if (connection.responseCode !in 200..299) return@runCatching null
                val body = connection.inputStream.bufferedReader().use { it.readText() }
                // A real JSON parser: the hand-rolled scanner mis-handled
                // escaped quotes and \uXXXX surrogate pairs.
                val json = JSONObject(body)
                json.optString("syncedLyrics").takeIf { it.isNotBlank() }
                    ?: json.optString("plainLyrics").takeIf { it.isNotBlank() }
            } finally {
                runCatching { connection.disconnect() }
            }
        }.getOrNull()

        if (result == null) synchronized(notFound) { notFound.add(cacheKey) }
        return result
    }

}

object LyricsParser {
    private val timeRegex = Regex("\\[(\\d{1,2}):(\\d{2})(?:[.:](\\d{1,3}))?]")

    fun parse(raw: String): Lyrics {
        val lines = ArrayList<LyricLine>()
        raw.lineSequence().forEach { line ->
            val matches = timeRegex.findAll(line).toList()
            if (matches.isEmpty()) return@forEach
            val text = line.substring(matches.last().range.last + 1).trim()
            matches.forEach { match ->
                val minutes = match.groupValues[1].toLongOrNull() ?: 0L
                val seconds = match.groupValues[2].toLongOrNull() ?: 0L
                val fraction = match.groupValues[3]
                val millis = when (fraction.length) {
                    0 -> 0L
                    1 -> fraction.toLong() * 100
                    2 -> fraction.toLong() * 10
                    else -> fraction.take(3).toLong()
                }
                lines += LyricLine(minutes * 60_000 + seconds * 1000 + millis, text)
            }
        }
        return if (lines.isNotEmpty()) {
            Lyrics(lines.sortedBy { it.timeMs }, raw, synchronized = true)
        } else {
            val plain = raw.lineSequence()
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .map { LyricLine(0L, it) }
                .toList()
            Lyrics(plain, raw, synchronized = false)
        }
    }

    /**
     * Finds the translation text for a given playback position by matching the
     * nearest synced translation timestamp (within [toleranceMs]).
     */
    fun translationAt(translationLines: List<LyricLine>, timeMs: Long, toleranceMs: Long = 1200): String? {
        if (translationLines.isEmpty()) return null
        var best: LyricLine? = null
        var bestDelta = Long.MAX_VALUE
        for (line in translationLines) {
            val delta = kotlin.math.abs(line.timeMs - timeMs)
            if (delta < bestDelta) {
                bestDelta = delta
                best = line
            }
        }
        return if (bestDelta <= toleranceMs) best?.text else null
    }
}
