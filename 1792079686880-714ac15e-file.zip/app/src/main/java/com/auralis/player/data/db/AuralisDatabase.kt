package com.auralis.player.data.db

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        SongEntity::class,
        PlaylistEntity::class,
        PlaylistSongEntity::class,
        PlayHistoryEntity::class,
        AbLoopEntity::class,
        EqPresetEntity::class,
        ExcludedFolderEntity::class,
        QueueItemEntity::class,
        QueueStateEntity::class,
        SmartPlaylistEntity::class
    ],
    version = 3,
    exportSchema = true
)
abstract class AuralisDatabase : RoomDatabase() {
    abstract fun songDao(): SongDao
    abstract fun playlistDao(): PlaylistDao
    abstract fun historyDao(): HistoryDao
    abstract fun abLoopDao(): AbLoopDao
    abstract fun eqPresetDao(): EqPresetDao
    abstract fun excludedFolderDao(): ExcludedFolderDao
    abstract fun queueDao(): QueueDao
    abstract fun smartPlaylistDao(): SmartPlaylistDao

    companion object {
        /**
         * Every schema change from version 3 on must land here. The database
         * holds data that exists nowhere else — playlists, favourites, play
         * counts, listening history, A-B loops and EQ presets — so a
         * destructive fallback is never acceptable for a released version.
         *
         * Template for the next change (bump `version` to 4 as well):
         *
         * ```
         * val MIGRATION_3_4 = object : Migration(3, 4) {
         *     override fun migrate(db: SupportSQLiteDatabase) {
         *         db.execSQL("ALTER TABLE songs ADD COLUMN rating INTEGER NOT NULL DEFAULT 0")
         *     }
         * }
         * ```
         */
        val MIGRATIONS: Array<Migration> = arrayOf()
    }
}
