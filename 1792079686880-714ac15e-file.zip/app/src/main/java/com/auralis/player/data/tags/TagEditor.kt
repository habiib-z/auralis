package com.auralis.player.data.tags

import android.app.Activity
import android.app.RecoverableSecurityException
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.content.FileProvider
import com.auralis.player.data.artwork.ArtworkLoader
import com.auralis.player.data.repository.MusicRepository
import com.auralis.player.domain.model.Song
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

data class TagUpdate(
    val title: String,
    val artist: String,
    val album: String,
    val albumArtist: String,
    val genre: String,
    val composer: String,
    val year: Int,
    val track: Int,
    val disc: Int,
    val lyrics: String?
)

sealed interface TagWriteResult {
    data object Success : TagWriteResult
    /** The system needs the user to approve the write; launch [intentSender]. */
    data class NeedsPermission(val intentSender: android.content.IntentSender) : TagWriteResult
    data class LocalOnly(val reason: String) : TagWriteResult
}

/**
 * Writes tags through MediaStore where the platform allows it, and always keeps
 * a local override so the library reflects the user's edit either way.
 *
 * Important limitation, surfaced to the user rather than hidden: this does
 * **not** rewrite the tag frames inside the audio file. On Android 10+ several
 * MediaStore columns (`GENRE`, `ALBUM_ARTIST`, `IS_RINGTONE`) are owned by the
 * platform scanner, so an edit can live only in Auralis and will not be seen
 * by other players — and a rescan triggered by another app can revert the
 * MediaStore side. Real on-file tag writing needs a tagging library and is
 * tracked separately.
 */
@Singleton
class TagEditor @Inject constructor(
    @ApplicationContext private val context: Context,
    private val musicRepository: MusicRepository,
    private val artworkLoader: ArtworkLoader
) {

    suspend fun apply(song: Song, update: TagUpdate): TagWriteResult = withContext(Dispatchers.IO) {
        musicRepository.updateTags(
            songId = song.id,
            title = update.title,
            artist = update.artist,
            album = update.album,
            albumArtist = update.albumArtist,
            genre = update.genre,
            composer = update.composer,
            year = update.year,
            track = update.track,
            disc = update.disc,
            lyrics = update.lyrics
        )
        artworkLoader.invalidate(song.id)

        val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, song.id)
        val values = ContentValues().apply {
            put(MediaStore.Audio.Media.TITLE, update.title)
            put(MediaStore.Audio.Media.ARTIST, update.artist)
            put(MediaStore.Audio.Media.ALBUM, update.album)
            put(MediaStore.Audio.Media.COMPOSER, update.composer)
            if (update.year > 0) put(MediaStore.Audio.Media.YEAR, update.year)
            if (update.track > 0) put(MediaStore.Audio.Media.TRACK, update.disc * 1000 + update.track)
            // ALBUM_ARTIST / GENRE are not writable on Android 10+: the
            // update is rejected (or silently dropped) and the whole batch can
            // fail with it. They are kept in Auralis' own database instead.
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                put(MediaStore.Audio.Media.ALBUM_ARTIST, update.albumArtist)
                put(MediaStore.Audio.Media.GENRE, update.genre)
            }
        }

        try {
            val updated = context.contentResolver.update(uri, values, null, null)
            if (updated > 0) {
                TagWriteResult.Success
            } else {
                TagWriteResult.LocalOnly("Saved in Auralis only — the file's own tags were not changed")
            }
        } catch (security: SecurityException) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val request = MediaStore.createWriteRequest(context.contentResolver, listOf(uri))
                TagWriteResult.NeedsPermission(request.intentSender)
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
                security is RecoverableSecurityException
            ) {
                TagWriteResult.NeedsPermission(security.userAction.actionIntent.intentSender)
            } else {
                TagWriteResult.LocalOnly("Saved in Auralis only — the file is read-only")
            }
        } catch (t: Throwable) {
            TagWriteResult.LocalOnly("Saved in Auralis only")
        }
    }

    suspend fun delete(song: Song): TagWriteResult = withContext(Dispatchers.IO) {
        val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, song.id)
        try {
            context.contentResolver.delete(uri, null, null)
            musicRepository.removeSongsFromLibrary(listOf(song.id))
            TagWriteResult.Success
        } catch (security: SecurityException) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val request = MediaStore.createDeleteRequest(context.contentResolver, listOf(uri))
                TagWriteResult.NeedsPermission(request.intentSender)
            } else {
                TagWriteResult.LocalOnly("Unable to delete this file")
            }
        } catch (t: Throwable) {
            TagWriteResult.LocalOnly("Unable to delete this file")
        }
    }

    /**
     * Deletes several tracks at once. On Android R+ a single system dialog can
     * cover the whole batch; below that the files are deleted one by one and
     * the first failure is reported.
     */
    suspend fun delete(songs: List<Song>): TagWriteResult = withContext(Dispatchers.IO) {
        if (songs.isEmpty()) return@withContext TagWriteResult.Success
        if (songs.size == 1) return@withContext delete(songs.first())

        val uris = songs.map { ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, it.id) }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            return@withContext try {
                val request = MediaStore.createDeleteRequest(context.contentResolver, uris)
                TagWriteResult.NeedsPermission(request.intentSender)
            } catch (t: Throwable) {
                TagWriteResult.LocalOnly("Unable to delete these files")
            }
        }

        val deleted = ArrayList<Long>(songs.size)
        var failures = 0
        songs.forEachIndexed { index, song ->
            try {
                context.contentResolver.delete(uris[index], null, null)
                deleted += song.id
            } catch (t: Throwable) {
                failures++
            }
        }
        if (deleted.isNotEmpty()) musicRepository.removeSongsFromLibrary(deleted)
        if (failures == 0) TagWriteResult.Success
        else TagWriteResult.LocalOnly("$failures of ${songs.size} files could not be deleted")
    }

    fun shareIntent(song: Song): Intent {
        val uri = resolveShareUri(song)
        return Intent(Intent.ACTION_SEND).apply {
            type = song.mimeType.ifBlank { "audio/*" }
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "${song.title} — ${song.displayArtist}")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    /** Share sheet for several tracks at once. */
    fun shareIntent(songs: List<Song>): Intent {
        if (songs.size == 1) return shareIntent(songs.first())
        val uris = ArrayList<Uri>(songs.map { resolveShareUri(it) })
        return Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "audio/*"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            putExtra(Intent.EXTRA_SUBJECT, "${songs.size} tracks")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    private fun resolveShareUri(song: Song): Uri = runCatching {
        if (song.path.startsWith("/")) {
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", File(song.path))
        } else {
            ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, song.id)
        }
    }.getOrElse {
        ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, song.id)
    }

    fun canWriteSystemSettings(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.System.canWrite(context)

    fun writeSettingsIntent(): Intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
        data = Uri.parse("package:${context.packageName}")
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    /** Sets the track as the device ringtone. Returns false when not permitted. */
    fun setAsRingtone(song: Song): Boolean {
        if (!canWriteSystemSettings()) return false
        return runCatching {
            val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, song.id)
            // IS_RINGTONE is read-only from Android 10 on; attempting it there
            // only throws, and setting the default ringtone works regardless.
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                runCatching {
                    context.contentResolver.update(
                        uri,
                        ContentValues().apply { put(MediaStore.Audio.Media.IS_RINGTONE, true) },
                        null,
                        null
                    )
                }
            }
            android.media.RingtoneManager.setActualDefaultRingtoneUri(
                context,
                android.media.RingtoneManager.TYPE_RINGTONE,
                uri
            )
            true
        }.getOrDefault(false)
    }

    companion object {
        fun activityOf(context: Context): Activity? {
            var current = context
            while (current is android.content.ContextWrapper) {
                if (current is Activity) return current
                current = current.baseContext
            }
            return null
        }
    }
}
