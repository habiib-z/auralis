package com.auralis.player.ui.screens.nowplaying

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.auralis.player.core.Formatters
import com.auralis.player.playback.AbLoopState
import com.auralis.player.playback.PlaybackPosition
import com.auralis.player.playback.SleepTimerState
import com.auralis.player.ui.components.AuralisChip
import com.auralis.player.ui.components.PressableSurface
import com.auralis.player.ui.components.SheetHandle
import com.auralis.player.ui.i18n.t
import com.auralis.player.ui.components.SwitchSetting
import com.auralis.player.ui.components.accentBrush
import com.auralis.player.ui.theme.AuralisTheme
import com.auralis.player.ui.theme.AuralisType
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

// ---------------------------------------------------------------------------
// Shared bits
// ---------------------------------------------------------------------------

@Composable
private fun SheetTitle(title: String, subtitle: String, centered: Boolean = false) {
    val colors = AuralisTheme.colors
    Column(
        modifier = if (centered) Modifier.fillMaxWidth() else Modifier,
        horizontalAlignment = if (centered) Alignment.CenterHorizontally else Alignment.Start
    ) {
        Text(
            title,
            style = AuralisType.headline,
            color = colors.textPrimary,
            textAlign = if (centered) TextAlign.Center else TextAlign.Start
        )
        Text(
            subtitle,
            style = AuralisType.bodySmall,
            color = colors.textSecondary,
            textAlign = if (centered) TextAlign.Center else TextAlign.Start
        )
    }
}

@Composable
private fun PrimaryPillButton(
    label: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val colors = AuralisTheme.colors
    PressableSurface(
        onClick = onClick,
        enabled = enabled,
        shape = AuralisTheme.shapes.chip,
        modifier = modifier
    ) {
        Box(
            modifier = Modifier
                .clip(AuralisTheme.shapes.chip)
                .background(accentBrush())
                .graphicsLayer { alpha = if (enabled) 1f else 0.45f }
                .padding(horizontal = 26.dp, vertical = 13.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(label, style = AuralisType.label, color = colors.onAccent, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun GhostPillButton(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val colors = AuralisTheme.colors
    PressableSurface(onClick = onClick, shape = AuralisTheme.shapes.chip, modifier = modifier) {
        Box(
            modifier = Modifier
                .clip(AuralisTheme.shapes.chip)
                .background(colors.surfaceMuted)
                .padding(horizontal = 22.dp, vertical = 13.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(label, style = AuralisType.label, color = colors.textPrimary)
        }
    }
}

// ---------------------------------------------------------------------------
// Sleep timer — radial dial with a live countdown ring.
// ---------------------------------------------------------------------------

private const val SLEEP_MIN = 5
private const val SLEEP_MAX = 120
private const val SLEEP_STEP = 5

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SleepTimerSheet(
    state: SleepTimerState,
    onDismiss: () -> Unit,
    onStart: (Int) -> Unit,
    onEndOfTrack: () -> Unit,
    onCancel: () -> Unit
) {
    val colors = AuralisTheme.colors
    val spacing = AuralisTheme.spacing
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var minutes by rememberSaveable { mutableIntStateOf(30) }

    // While the timer runs the ring shows what is left, not what was dialled.
    val running = state.active && !state.stopAtTrackEnd
    val totalMs = remember(state.active) { state.remainingMs.coerceAtLeast(1L) }
    val remainingFraction = if (running) {
        (state.remainingMs.toFloat() / totalMs.toFloat()).coerceIn(0f, 1f)
    } else {
        null
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = colors.backgroundElevated,
        dragHandle = { SheetHandle() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(horizontal = spacing.screen, vertical = spacing.sm),
            verticalArrangement = Arrangement.spacedBy(spacing.md),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            SheetTitle(
                title = t("Sleep timer"),
                subtitle = when {
                    state.stopAtTrackEnd -> t("Stops at the end of this track")
                    running -> t("Running — fades out and pauses when it reaches zero")
                    else -> t("Drag the dial, or pick a preset")
                },
                centered = true
            )

            RadialMinutePicker(
                minutes = minutes,
                onMinutes = { minutes = it },
                enabled = !state.stopAtTrackEnd,
                ringFraction = remainingFraction
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    if (running) {
                        Text(
                            text = Formatters.duration(state.remainingMs),
                            style = AuralisType.display,
                            color = colors.accent
                        )
                        Text(t("remaining"), style = AuralisType.bodySmall, color = colors.textSecondary)
                    } else {
                        Text(
                            text = minutes.toString(),
                            style = AuralisType.display,
                            color = if (state.stopAtTrackEnd) colors.textTertiary else colors.accent
                        )
                        Text(t("minutes"), style = AuralisType.bodySmall, color = colors.textSecondary)
                    }
                }
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(spacing.xs),
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf(15, 30, 45, 60, 90).forEach { preset ->
                    AuralisChip(
                        label = "${preset}m",
                        selected = minutes == preset && !state.stopAtTrackEnd,
                        modifier = Modifier.weight(1f)
                    ) { minutes = preset }
                }
            }

            OptionTile(
                title = t("Stop at end of track"),
                subtitle = t("Finish this song, then pause"),
                selected = state.stopAtTrackEnd,
                onClick = { if (state.stopAtTrackEnd) onCancel() else onEndOfTrack() }
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(spacing.sm),
                modifier = Modifier.fillMaxWidth()
            ) {
                PrimaryPillButton(
                    label = if (running) t("Update timer") else t("Start timer"),
                    enabled = !state.stopAtTrackEnd,
                    modifier = Modifier.weight(1f)
                ) {
                    onStart(minutes)
                    onDismiss()
                }
                if (state.active || state.stopAtTrackEnd) {
                    GhostPillButton(label = t("Cancel"), modifier = Modifier.weight(0.65f)) {
                        onCancel()
                        onDismiss()
                    }
                }
            }
            Box(modifier = Modifier.height(spacing.md))
        }
    }
}

/**
 * Circular minute dial. The whole ring maps to [SLEEP_MIN]..[SLEEP_MAX]; a drag
 * that would wrap past either end is ignored, so the value cannot jump from
 * two hours to five minutes by accident.
 */
@Composable
private fun RadialMinutePicker(
    minutes: Int,
    onMinutes: (Int) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    ringFraction: Float? = null,
    center: @Composable () -> Unit
) {
    val colors = AuralisTheme.colors
    val haptic = LocalHapticFeedback.current
    val steps = (SLEEP_MAX - SLEEP_MIN) / SLEEP_STEP
    val valueFraction = (minutes - SLEEP_MIN).toFloat() / (SLEEP_MAX - SLEEP_MIN)
    val sweep = (ringFraction ?: valueFraction).coerceIn(0f, 1f)
    val animatedSweep by animateFloatAsState(sweep, label = "dialSweep")

    val trackColor = colors.outline.copy(alpha = 0.35f)
    val tickColor = colors.textTertiary.copy(alpha = 0.5f)
    val accent = colors.accent
    val glow = colors.accentGlow
    val dimmed = if (enabled) 1f else 0.4f

    Box(
        modifier = modifier
            .size(220.dp)
            .graphicsLayer { alpha = dimmed }
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                var last = minutes
                fun handle(pos: Offset) {
                    val next = dialValue(pos, size.width.toFloat(), size.height.toFloat())
                        ?: return
                    // Reject the wrap-around jump between the two ends.
                    if (kotlin.math.abs(next - last) > (SLEEP_MAX - SLEEP_MIN) / 2) return
                    if (next != last) {
                        last = next
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onMinutes(next)
                    }
                }
                detectDragGestures(
                    onDragStart = { last = minutes; handle(it) },
                    onDrag = { change, _ ->
                        change.consume()
                        handle(change.position)
                    }
                )
            }
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                detectTapGestures { pos ->
                    dialValue(pos, size.width.toFloat(), size.height.toFloat())?.let(onMinutes)
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxWidth().aspectRatio(1f)) {
            val stroke = 16.dp.toPx()
            val inset = stroke / 2f + 10.dp.toPx()
            val diameter = size.minDimension - inset * 2f
            val topLeft = Offset(inset, inset)
            val arcSize = Size(diameter, diameter)
            val radius = diameter / 2f
            val middle = Offset(size.width / 2f, size.height / 2f)

            // Tick marks, one per selectable step.
            repeat(steps + 1) { i ->
                val angle = (-90f + i * 360f / steps) * (PI / 180f).toFloat()
                val outer = radius + stroke / 2f + 6.dp.toPx()
                val isMajor = i % 3 == 0
                val length = if (isMajor) 7.dp.toPx() else 4.dp.toPx()
                drawLine(
                    color = tickColor,
                    start = middle + Offset(cos(angle) * outer, sin(angle) * outer),
                    end = middle + Offset(
                        cos(angle) * (outer + length),
                        sin(angle) * (outer + length)
                    ),
                    strokeWidth = if (isMajor) 2.dp.toPx() else 1.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }

            drawArc(
                color = trackColor,
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )
            drawArc(
                brush = Brush.sweepGradient(listOf(accent, glow, accent)),
                startAngle = -90f,
                sweepAngle = (animatedSweep * 360f).coerceAtLeast(2f),
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )

            // Knob at the head of the arc.
            val knobAngle = (-90f + animatedSweep * 360f) * (PI / 180f).toFloat()
            val knob = middle + Offset(cos(knobAngle) * radius, sin(knobAngle) * radius)
            drawCircle(color = accent.copy(alpha = 0.22f), radius = 16.dp.toPx(), center = knob)
            drawCircle(color = accent, radius = 9.dp.toPx(), center = knob)
        }
        center()
    }
}

/** Maps a touch inside the dial to a snapped minute value. */
private fun dialValue(pos: Offset, width: Float, height: Float): Int? {
    val dx = pos.x - width / 2f
    val dy = pos.y - height / 2f
    if (kotlin.math.abs(dx) < 1f && kotlin.math.abs(dy) < 1f) return null
    var degrees = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat() + 90f
    if (degrees < 0f) degrees += 360f
    val steps = (SLEEP_MAX - SLEEP_MIN) / SLEEP_STEP
    val index = (degrees / 360f * steps).roundToInt().coerceIn(0, steps)
    return SLEEP_MIN + index * SLEEP_STEP
}

/** Selectable card row used for the one-off timer modes. */
@Composable
private fun OptionTile(
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = AuralisTheme.colors
    val border by animateColorAsState(
        if (selected) colors.accent else colors.outline.copy(alpha = 0.5f),
        label = "optionTileBorder"
    )
    PressableSurface(onClick = onClick, shape = AuralisTheme.shapes.card, modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(AuralisTheme.shapes.card)
                .background(if (selected) colors.accentSoft else colors.surfaceMuted)
                .border(if (selected) 1.5.dp else 1.dp, border, AuralisTheme.shapes.card)
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = AuralisType.body, color = colors.textPrimary)
                Text(subtitle, style = AuralisType.bodySmall, color = colors.textSecondary)
            }
            Box(
                modifier = Modifier
                    .size(22.dp)
                    .clip(CircleShape)
                    .background(if (selected) colors.accent else androidx.compose.ui.graphics.Color.Transparent)
                    .border(1.5.dp, if (selected) colors.accent else colors.outline, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                if (selected) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(colors.onAccent)
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Playback speed — snapping tape dial.
// ---------------------------------------------------------------------------

private val SPEED_VALUES: List<Float> =
    generateSequence(0.25f) { it + 0.05f }
        .takeWhile { it <= 4.001f }
        .map { (it * 100).roundToInt() / 100f }
        .toList()

private fun speedLabel(value: Float): String {
    val hundredths = (value * 100).roundToInt()
    return when {
        hundredths % 100 == 0 -> "${hundredths / 100}×"
        hundredths % 10 == 0 -> String.format("%.1f×", value)
        else -> String.format("%.2f×", value)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpeedSheet(
    currentSpeed: Float,
    onDismiss: () -> Unit,
    onSpeed: (Float) -> Unit
) {
    val colors = AuralisTheme.colors
    val spacing = AuralisTheme.spacing
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = colors.backgroundElevated,
        dragHandle = { SheetHandle() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(vertical = spacing.sm),
            verticalArrangement = Arrangement.spacedBy(spacing.md),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = spacing.screen)) {
                SheetTitle(
                    title = t("Playback speed"),
                    subtitle = t("Pitch is preserved · remembered across sessions"),
                    centered = true
                )
            }

            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = String.format("%.2f", currentSpeed),
                    style = AuralisType.display,
                    color = colors.accent
                )
                Text(
                    text = "×",
                    style = AuralisType.headline,
                    color = colors.textSecondary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 6.dp)
                )
            }

            SpeedTape(currentSpeed = currentSpeed, onSpeed = onSpeed)

            Row(
                horizontalArrangement = Arrangement.spacedBy(spacing.xs),
                modifier = Modifier.fillMaxWidth().padding(horizontal = spacing.screen)
            ) {
                listOf(0.75f, 1f, 1.25f, 1.5f, 2f).forEach { preset ->
                    AuralisChip(
                        label = speedLabel(preset),
                        selected = kotlin.math.abs(currentSpeed - preset) < 0.011f,
                        modifier = Modifier.weight(1f)
                    ) { onSpeed(preset) }
                }
            }

            GhostPillButton(label = t("Reset to normal")) { onSpeed(1f) }

            Box(modifier = Modifier.height(spacing.lg))
        }
    }
}

/**
 * Horizontal tape dial: the strip scrolls under a fixed accent needle and
 * snaps to the nearest 0.05 step, with a tick for every value and a label on
 * the quarter steps.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SpeedTape(
    currentSpeed: Float,
    onSpeed: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = AuralisTheme.colors
    val haptic = LocalHapticFeedback.current
    val itemWidth = 26.dp
    val listState = rememberLazyListState()
    val flingBehavior = rememberSnapFlingBehavior(lazyListState = listState)

    val index = remember(currentSpeed) {
        SPEED_VALUES.indexOfFirst { kotlin.math.abs(it - currentSpeed) < 0.026f }
            .coerceAtLeast(0)
    }

    // Follow external changes (presets, reset) without fighting the drag.
    LaunchedEffect(index) {
        if (!listState.isScrollInProgress) listState.animateScrollToItem(index)
    }

    // Report the centred value once the strip comes to rest.
    val settledIndex by remember {
        derivedStateOf {
            if (listState.layoutInfo.visibleItemsInfo.isEmpty()) index
            else listState.firstVisibleItemIndex +
                if (listState.firstVisibleItemScrollOffset > 0) 1 else 0
        }
    }
    LaunchedEffect(settledIndex, listState.isScrollInProgress) {
        if (listState.isScrollInProgress) {
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        } else {
            val value = SPEED_VALUES.getOrNull(settledIndex) ?: return@LaunchedEffect
            if (kotlin.math.abs(value - currentSpeed) > 0.001f) onSpeed(value)
        }
    }

    BoxWithConstraints(modifier = modifier.fillMaxWidth().height(96.dp)) {
        val sidePadding = (maxWidth - itemWidth) / 2
        LazyRow(
            state = listState,
            flingBehavior = flingBehavior,
            contentPadding = PaddingValues(horizontal = sidePadding),
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Bottom
        ) {
            items(SPEED_VALUES.size) { i ->
                val value = SPEED_VALUES[i]
                val major = (value * 100).roundToInt() % 25 == 0
                val selected = i == settledIndex
                Column(
                    modifier = Modifier.width(itemWidth).height(76.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Bottom
                ) {
                    if (major) {
                        Text(
                            text = speedLabel(value),
                            style = AuralisType.bodySmall,
                            color = if (selected) colors.accent else colors.textTertiary
                        )
                    }
                    Box(
                        modifier = Modifier
                            .padding(top = 6.dp)
                            .width(if (major) 2.dp else 1.5.dp)
                            .height(if (major) 26.dp else 14.dp)
                            .clip(CircleShape)
                            .background(
                                if (selected) colors.accent
                                else colors.textTertiary.copy(alpha = if (major) 0.65f else 0.35f)
                            )
                    )
                }
            }
        }

        // Fixed needle + soft edge fades so the strip reads as a physical dial.
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .width(3.dp)
                .height(44.dp)
                .clip(CircleShape)
                .background(colors.accent)
        )
        Box(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .fillMaxHeight()
                .width(40.dp)
                .background(
                    Brush.horizontalGradient(
                        listOf(colors.backgroundElevated, colors.backgroundElevated.copy(alpha = 0f))
                    )
                )
        )
        Box(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .fillMaxHeight()
                .width(40.dp)
                .background(
                    Brush.horizontalGradient(
                        listOf(colors.backgroundElevated.copy(alpha = 0f), colors.backgroundElevated)
                    )
                )
        )
    }
}

// ---------------------------------------------------------------------------
// A-B loop — visual range over the track timeline.
// ---------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AbLoopSheet(
    loop: AbLoopState,
    positionFlow: StateFlow<PlaybackPosition>,
    onDismiss: () -> Unit,
    onMarkStart: () -> Unit,
    onMarkEnd: () -> Unit,
    onToggle: (Boolean) -> Unit,
    onClear: () -> Unit
) {
    val colors = AuralisTheme.colors
    val spacing = AuralisTheme.spacing
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = colors.backgroundElevated,
        dragHandle = { SheetHandle() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = spacing.screen, vertical = spacing.sm),
            verticalArrangement = Arrangement.spacedBy(spacing.md)
        ) {
            SheetTitle(
                title = "A-B repeat",
                subtitle = when {
                    loop.ready && loop.enabled -> "Looping between the two markers"
                    loop.ready -> "Range set — flip the switch to start looping"
                    loop.startMs != null -> "Now play to the end point and set B"
                    else -> "Repeat any section of this track"
                }
            )

            AbTimeline(loop = loop, positionFlow = positionFlow)

            Row(
                horizontalArrangement = Arrangement.spacedBy(spacing.sm),
                modifier = Modifier.fillMaxWidth()
            ) {
                PrimaryPillButton(
                    label = loop.startMs?.let { "A · ${Formatters.duration(it)}" } ?: "Set A here",
                    modifier = Modifier.weight(1f)
                ) { onMarkStart() }
                PrimaryPillButton(
                    label = loop.endMs?.let { "B · ${Formatters.duration(it)}" } ?: "Set B here",
                    modifier = Modifier.weight(1f),
                    enabled = loop.startMs != null
                ) { onMarkEnd() }
            }

            SwitchSetting(
                label = "Loop enabled",
                checked = loop.enabled,
                description = if (loop.ready) null else "Set both markers first"
            ) { if (loop.ready) onToggle(it) }

            if (loop.startMs != null || loop.endMs != null) {
                GhostPillButton(label = "Clear markers", modifier = Modifier.fillMaxWidth()) {
                    onClear()
                }
            }
            Box(modifier = Modifier.height(spacing.md))
        }
    }
}

/** Track timeline with the loop range, A/B markers and a live playhead. */
@Composable
private fun AbTimeline(loop: AbLoopState, positionFlow: StateFlow<PlaybackPosition>) {
    val colors = AuralisTheme.colors
    val position by positionFlow.collectAsStateWithLifecycle()
    val duration = position.durationMs.coerceAtLeast(1L)
    val aFrac = (loop.startMs ?: 0L).toFloat() / duration
    val bFrac = (loop.endMs ?: duration).toFloat() / duration
    val playFrac = position.positionMs.toFloat() / duration
    val hasA = loop.startMs != null
    val hasB = loop.endMs != null
    val rangeColor by animateColorAsState(
        if (loop.enabled) colors.accent else colors.accent.copy(alpha = 0.45f),
        label = "abRange"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp)
            .drawBehind {
                val trackH = 8.dp.toPx()
                val y = size.height / 2f
                val corner = CornerRadius(trackH / 2f)
                // base
                drawRoundRect(
                    color = colors.surfaceMuted,
                    topLeft = Offset(0f, y - trackH / 2f),
                    size = Size(size.width, trackH),
                    cornerRadius = corner
                )
                // loop range
                if (hasA || hasB) {
                    val x0 = size.width * aFrac.coerceIn(0f, 1f)
                    val x1 = size.width * bFrac.coerceIn(0f, 1f)
                    if (x1 > x0) {
                        drawRoundRect(
                            color = rangeColor,
                            topLeft = Offset(x0, y - trackH / 2f),
                            size = Size(x1 - x0, trackH),
                            cornerRadius = corner
                        )
                    }
                }
                // playhead
                val px = size.width * playFrac.coerceIn(0f, 1f)
                drawLine(
                    color = colors.textPrimary,
                    start = Offset(px, y - 16.dp.toPx()),
                    end = Offset(px, y + 16.dp.toPx()),
                    strokeWidth = 2.dp.toPx()
                )
                // markers
                if (hasA) {
                    drawCircle(color = colors.accent, radius = 8.dp.toPx(), center = Offset(size.width * aFrac, y))
                    drawCircle(color = colors.onAccent, radius = 3.dp.toPx(), center = Offset(size.width * aFrac, y))
                }
                if (hasB) {
                    drawCircle(color = colors.accent, radius = 8.dp.toPx(), center = Offset(size.width * bFrac, y))
                    drawCircle(color = colors.onAccent, radius = 3.dp.toPx(), center = Offset(size.width * bFrac, y))
                }
            }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(Formatters.duration(position.positionMs), style = AuralisType.numeric, color = colors.textSecondary)
            Text(Formatters.duration(position.durationMs), style = AuralisType.numeric, color = colors.textSecondary)
        }
    }
}
