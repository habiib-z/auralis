package com.auralis.player.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.auralis.player.domain.model.Song
import com.auralis.player.ui.i18n.t
import com.auralis.player.ui.theme.AuralisTheme
import com.auralis.player.ui.theme.AuralisType

/**
 * Multi-select state for a song list. Survives configuration changes and
 * process death, so a rotation in the middle of picking 40 tracks is harmless.
 */
@Stable
class SelectionState internal constructor(initial: Set<Long> = emptySet()) {

    var selectedIds: Set<Long> by mutableStateOf(initial)
        private set

    val active: Boolean get() = selectedIds.isNotEmpty()
    val count: Int get() = selectedIds.size

    fun isSelected(id: Long): Boolean = id in selectedIds

    fun toggle(id: Long) {
        selectedIds = if (id in selectedIds) selectedIds - id else selectedIds + id
    }

    fun selectAll(ids: Collection<Long>) {
        selectedIds = ids.toSet()
    }

    fun clear() {
        selectedIds = emptySet()
    }

    /** Selection order is irrelevant, so the ids alone restore the state. */
    internal companion object {
        val Saver = listSaver<SelectionState, Long>(
            save = { it.selectedIds.toList() },
            restore = { SelectionState(it.toSet()) }
        )
    }
}

@Composable
fun rememberSelectionState(key: String): SelectionState =
    rememberSaveable(saver = SelectionState.Saver, key = key) { SelectionState() }

/**
 * Header shown in place of a screen's title while tracks are selected:
 * close, the running count and select-all / select-none.
 */
@Composable
fun SelectionHeader(
    selection: SelectionState,
    totalCount: Int,
    onSelectAll: () -> Unit,
    modifier: Modifier = Modifier,
    statusBarPadding: Boolean = true
) {
    val colors = AuralisTheme.colors
    val spacing = AuralisTheme.spacing
    val allSelected = selection.count >= totalCount && totalCount > 0
    Row(
        modifier = modifier
            .fillMaxWidth()
            .then(if (statusBarPadding) Modifier.statusBarsPadding() else Modifier)
            .padding(horizontal = spacing.md, vertical = spacing.sm),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AccentIconButton(Icons.Rounded.Close, t("Cancel selection")) { selection.clear() }
        Text(
            text = t("%d selected").format(selection.count),
            style = AuralisType.title,
            color = colors.textPrimary,
            modifier = Modifier
                .weight(1f)
                .padding(start = spacing.sm)
        )
        AuralisChip(
            label = if (allSelected) t("None") else t("All"),
            selected = allSelected,
            leadingIcon = Icons.Rounded.DoneAll,
            onClick = { if (allSelected) selection.clear() else onSelectAll() }
        )
    }
}

/**
 * Action strip for the current selection. [resolve] is only called when an
 * action is tapped, so nothing is recomputed while the user keeps picking.
 */
@Composable
fun SelectionActionBar(
    selection: SelectionState,
    resolve: () -> List<Song>,
    modifier: Modifier = Modifier
) {
    val actions = LocalSelectionActions.current ?: return
    val spacing = AuralisTheme.spacing

    fun dispatch(block: (List<Song>) -> Unit) {
        val songs = resolve()
        if (songs.isEmpty()) return
        block(songs)
    }

    LazyRow(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = spacing.screen),
        horizontalArrangement = Arrangement.spacedBy(spacing.sm)
    ) {
        item {
            AuralisChip(t("Play"), selected = true, leadingIcon = Icons.Rounded.PlayArrow) {
                dispatch { actions.onPlay(it); selection.clear() }
            }
        }
        item {
            AuralisChip(t("Shuffle"), selected = false, leadingIcon = Icons.Rounded.Shuffle) {
                dispatch { actions.onShuffle(it); selection.clear() }
            }
        }
        item {
            AuralisChip(t("Play next"), selected = false, leadingIcon = Icons.Rounded.SkipNext) {
                dispatch { actions.onPlayNext(it); selection.clear() }
            }
        }
        item {
            AuralisChip(t("Add to queue"), selected = false, leadingIcon = Icons.Rounded.QueueMusic) {
                dispatch { actions.onAddToQueue(it); selection.clear() }
            }
        }
        item {
            AuralisChip(t("Add to playlist"), selected = false, leadingIcon = Icons.Rounded.PlaylistAdd) {
                dispatch { actions.onAddToPlaylist(it); selection.clear() }
            }
        }
        item {
            AuralisChip(t("Favorite"), selected = false, leadingIcon = Icons.Rounded.Favorite) {
                dispatch { actions.onToggleFavorite(it); selection.clear() }
            }
        }
        item {
            AuralisChip(t("Share"), selected = false, leadingIcon = Icons.Rounded.Share) {
                dispatch { actions.onShare(it); selection.clear() }
            }
        }
        item {
            AuralisChip(t("Delete"), selected = false, leadingIcon = Icons.Rounded.Delete) {
                dispatch { actions.onDelete(it); selection.clear() }
            }
        }
    }
}

/** Header + actions, animated in and out together. */
@Composable
fun SelectionToolbar(
    selection: SelectionState,
    totalCount: Int,
    onSelectAll: () -> Unit,
    resolve: () -> List<Song>,
    modifier: Modifier = Modifier,
    statusBarPadding: Boolean = true
) {
    // Back exits the selection before it leaves the screen.
    BackHandler(enabled = selection.active) { selection.clear() }
    AnimatedVisibility(
        visible = selection.active,
        enter = fadeIn() + expandVertically(),
        exit = fadeOut() + shrinkVertically(),
        modifier = modifier
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            SelectionHeader(
                selection = selection,
                totalCount = totalCount,
                onSelectAll = onSelectAll,
                statusBarPadding = statusBarPadding
            )
            SelectionActionBar(
                selection = selection,
                resolve = resolve,
                modifier = Modifier.padding(bottom = AuralisTheme.spacing.sm)
            )
        }
    }
}

/** Round check indicator drawn in place of the artwork while selecting. */
@Composable
fun SelectionCheck(selected: Boolean, modifier: Modifier = Modifier, size: androidx.compose.ui.unit.Dp = 24.dp) {
    val colors = AuralisTheme.colors
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(if (selected) colors.accent else Color.Transparent)
            .border(1.5.dp, if (selected) colors.accent else colors.outline, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        if (selected) {
            Icon(
                Icons.Rounded.Check,
                contentDescription = null,
                tint = colors.onAccent,
                modifier = Modifier.size(size * 0.62f)
            )
        }
    }
}
