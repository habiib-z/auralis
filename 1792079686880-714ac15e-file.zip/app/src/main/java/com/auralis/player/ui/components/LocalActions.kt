package com.auralis.player.ui.components

import androidx.compose.runtime.compositionLocalOf
import com.auralis.player.domain.model.Song

/**
 * Favourite toggle provided once by the app scaffold, so every row and the
 * player share one write path and update on the first tap.
 */
val LocalFavoriteToggle = compositionLocalOf<((Song) -> Unit)?> { null }

/** Everything the multi-select toolbar can do with the picked tracks. */
data class SelectionActions(
    val onPlay: (List<Song>) -> Unit,
    val onShuffle: (List<Song>) -> Unit,
    val onPlayNext: (List<Song>) -> Unit,
    val onAddToQueue: (List<Song>) -> Unit,
    val onAddToPlaylist: (List<Song>) -> Unit,
    val onToggleFavorite: (List<Song>) -> Unit,
    val onShare: (List<Song>) -> Unit,
    val onDelete: (List<Song>) -> Unit
)

/**
 * Provided once by the app scaffold; the song lists only own the selection
 * itself, not what happens to it.
 */
val LocalSelectionActions = compositionLocalOf<SelectionActions?> { null }
