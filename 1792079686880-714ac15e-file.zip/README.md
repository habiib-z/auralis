# Auralis Player

A local-first Android music player. Kotlin · Jetpack Compose · Hilt · Room · Media3.

**Version 1.0.0** — first public release.
Source: <https://github.com/habiib-z>

## Features

- **Offline by design** — no account, no analytics, no background upload. Your library,
  statistics and settings never leave the device.
- **Seven design systems**, switchable at runtime without a restart: Aurora, Luxury Gold,
  Scandinavian, Dynamic (Material You), Soft UI, AMOLED and Experimental. Each one carries its
  own colors, corner language, typography and motion personality.
- **Media3 playback service** with media-session controls, lock-screen and notification
  artwork, Quick Settings tile, home-screen widgets, sleep timer and A–B loop.
- **Lyrics** — embedded (ID3v2 USLT / FLAC Vorbis comments), local `.lrc` files, and optional
  online lookup from lrclib.net. Synced highlighting, translation line, Persian font support.
- **Library** — fast MediaStore scanner with folder exclusions and automatic rescan when the
  media store changes, playlists, smart playlists, tag editing and a file-based browser.
- **Multi-select** — long-press any track in Songs, Favorites or a collection to select a
  group, then play, shuffle, queue, add to a playlist, favourite, share or delete the whole
  selection at once.
- **Statistics** — listening history, per-day charts and a year-in-review screen.
- **Audio** — equalizer with presets, bass/treble, balance, playback speed, loudness
  normalization and a visualizer.
- **Backup & restore** to a single file, optionally encrypted with a passphrase
  (PBKDF2-HMAC-SHA256 + AES-GCM).
- **English and Persian** interface with full RTL layout.

## Build

```bash
echo "sdk.dir=$HOME/Android/Sdk" > local.properties
./gradlew assembleDebug
```

Requirements: JDK 17, Android SDK 34.

### Signing a release

Release builds are unsigned unless you supply a keystore through Gradle properties or
environment variables:

```
AURALIS_KEYSTORE=/path/to/keystore.jks
AURALIS_KEYSTORE_PASSWORD=...
AURALIS_KEY_ALIAS=...
AURALIS_KEY_PASSWORD=...
```

```bash
./gradlew test lintDebug assembleRelease
```

## License

See [LICENSE](LICENSE).
